package br.com.sinerji.comprascrawler.crawler.pncp;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.ClientProtocolException;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import br.com.sinerji.comprascrawler.Config;
import br.com.sinerji.comprascrawler.crawler.Crawler;
import br.com.sinerji.comprascrawler.crawler.CrawlerException;
import br.com.sinerji.comprascrawler.crawler.FetchChecker;
import br.com.sinerji.comprascrawler.http.HttpBot;
import br.com.sinerji.comprascrawler.http.client.HttpResponse;
import br.com.sinerji.comprascrawler.util.FileUtil;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class PNCPArchivesCrawler extends Crawler {
    protected static final int SMALL_CODE_LENGTH = 6;

    private static final String PNCP_ARCHIVES_URL_FORMAT = "https://pncp.gov.br/api/pncp/v1/orgaos/%s/compras/%s/%s/arquivos?pagina=1&tamanhoPagina=500";
    private static final String PNCP_ARCHIVES_FILE_TYPE = "json";

    private final FetchChecker fetchChecker;
    private final File pncpArchivesDir;

    public PNCPArchivesCrawler(Config config, HttpBot bot) {
        super(config, bot);
        pncpArchivesDir = config.getEditaisDir();
        log.info("Diretório configurado para arquivos PNCP: {}", pncpArchivesDir.getAbsolutePath());
        FileUtil.createDirectoryIfNotExists(pncpArchivesDir);
        fetchChecker = new FetchChecker(config, "fetched_pncp_archives.txt");
    }

    @Override
    protected void runCrawler() throws ClientProtocolException, IOException {
        log.info("Iniciando extração de parâmetros de arquivos PNCP...");
        Set<PncpArchivesParams> pncpArchivesParamsList = getPncpArchivesParamsSet();
        int counter = 0;

        for (PncpArchivesParams params : pncpArchivesParamsList) {
            log.info("Tentando buscar arquivo para: {}", params.getId());
            fetchPncpArchive(params);
            counter++;
            if (counter % 20 == 0) {
                log.info(String.format("%d/%d arquivos processados", counter, pncpArchivesParamsList.size()));
            }
        }

        log.info("Processamento de arquivos PNCP concluído. Total de arquivos processados: {}", counter);
    }

    protected abstract String getTypeFilter();

    protected Set<PncpArchivesParams> getPncpArchivesParamsSet() {
        log.info("Iniciando extração de parâmetros de arquivos PNCP...");
        Set<PncpArchivesParams> pncpArchivesParamsSet = new HashSet<>();
        List<File> pagesDirFiles = FileUtil.listDirFilesOrdered(pncpArchivesDir);

        log.info("Número total de arquivos encontrados no diretório: {}", pagesDirFiles.size());

        for (File pageFile : pagesDirFiles) {
            log.info("Processando arquivo: {}", pageFile.getName());
            String jsonStr = FileUtil.readFile(pageFile);

            try {
                JsonElement json = JsonParser.parseString(jsonStr);
                if (!json.isJsonObject()) {
                    log.warn("Formato de JSON inválido no arquivo: {}", pageFile.getName());
                    continue;
                }

                JsonObject dataObj = json.getAsJsonObject();
                JsonArray items = dataObj.getAsJsonArray("items");
                if (items == null || items.size() == 0) {
                    log.warn("Nenhum item encontrado no arquivo: {}", pageFile.getName());
                    continue;
                }

                log.info("Número de itens encontrados no arquivo {}: {}", pageFile.getName(), items.size());

                for (JsonElement item : items) {
                    if (!item.isJsonObject()) {
                        log.warn("Item inválido (não é um objeto JSON) no arquivo: {}", pageFile.getName());
                        continue;
                    }

                    JsonObject itemObj = item.getAsJsonObject();
                    String documentType = itemObj.has("document_type") ? itemObj.get("document_type").getAsString() : null;

                    log.debug("document_type: {}", documentType);

                    if (documentType == null || !getTypeFilter().equalsIgnoreCase(documentType)) {
                        log.debug("document_type não corresponde ao filtro esperado ('{}') no arquivo: {}", getTypeFilter(), pageFile.getName());
                        continue;
                    }

                    String itemUrl = itemObj.has("item_url") ? itemObj.get("item_url").getAsString() : null;
                    if (itemUrl == null || itemUrl.isEmpty()) {
                        log.warn("URL do item está ausente ou vazia no arquivo: {}", pageFile.getName());
                        continue;
                    }

                    String[] split = itemUrl.replace("/" + getTypeFilter() + "/", "").split("/");
                    if (split.length < 3) {
                        log.warn("Formato de URL inválido: {}", itemUrl);
                        continue;
                    }

                    String largeCode = split[0];
                    String year = split[1];
                    String smallCode = split[2];

                    log.info("Parâmetros extraídos: largeCode={}, year={}, smallCode={}", largeCode, year, smallCode);

                    pncpArchivesParamsSet.add(PncpArchivesParams.builder()
                            .largeCode(largeCode)
                            .year(year)
                            .smallCode(smallCode)
                            .build());
                }
            } catch (Exception e) {
                log.error("Erro ao processar o arquivo {}: {}", pageFile.getName(), e.getMessage());
            }
        }

        log.info("Extração concluída. Total de parâmetros extraídos: {}", pncpArchivesParamsSet.size());
        return pncpArchivesParamsSet;
    }

    private void fetchPncpArchive(PncpArchivesParams params) throws IOException {
        String id = params.getId();
        File pncpArchivesFile = new File(pncpArchivesDir, String.format("%s.%s", id, PNCP_ARCHIVES_FILE_TYPE));

        if (pncpArchivesFile.exists() || fetchChecker.contains(id)) {
            log.info("Arquivo já existe ou já foi buscado anteriormente: {}", id);
            return;
        }

        log.info("Buscando arquivo PNCP para: {}", id);
        log.debug("URL de busca: {}", params.getPncpArchivesUrl());

        HttpResponse response = bot.doGet(params.getPncpArchivesUrl());
        fetchChecker.updateFetchedSetFile(id);

        String result = response.getResult();
        if (result != null) {
            try {
                validateResult(result);
                log.info("Arquivo válido recebido para ID: {}", id);
                FileUtil.writeToFile(pncpArchivesFile, result);
                log.info("Arquivo salvo em: {}", pncpArchivesFile.getAbsolutePath());
            } catch (CrawlerException e) {
                log.warn("Resultado inválido para ID {}: {}", id, e.getMessage());
            }
        } else {
            log.warn("Nenhum resultado retornado para ID: {}", id);
        }
    }

    private void validateResult(String result) throws CrawlerException {
        JsonElement json = JsonParser.parseString(result);
        if (!json.isJsonArray()) {
            log.error("Erro ao validar o resultado: o resultado não é um array JSON.");
            throw new CrawlerException("Response is not an array");
        }
    }

    @Builder
    @AllArgsConstructor(access = AccessLevel.PRIVATE)
    protected static class PncpArchivesParams {
        private final String largeCode;
        private final String year;
        private String smallCode;

        public String getPncpArchivesUrl() {
            String formattedSmallCode = getFormattedSmallCode();
            String url = String.format(PNCP_ARCHIVES_URL_FORMAT, largeCode, year, formattedSmallCode);
            log.debug("URL gerada para o arquivo: {}", url);
            return url;
        }

        public String getId() {
            String formattedSmallCode = getFormattedSmallCode();
            String id = String.format("%s-%s-%s", largeCode, formattedSmallCode, year);
            log.debug("ID gerado para o arquivo: {}", id);
            return id;
        }

        private String getFormattedSmallCode() {
            return StringUtils.leftPad(smallCode, SMALL_CODE_LENGTH, '0');
        }

        @Override
        public int hashCode() {
            return Objects.hash(getId());
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            PncpArchivesParams other = (PncpArchivesParams) obj;
            return Objects.equals(getId(), other.getId());
        }
    }
}
