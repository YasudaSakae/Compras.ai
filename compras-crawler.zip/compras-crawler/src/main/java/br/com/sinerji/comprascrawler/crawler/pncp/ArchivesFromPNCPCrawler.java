package br.com.sinerji.comprascrawler.crawler.pncp;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import br.com.sinerji.comprascrawler.Config;
import br.com.sinerji.comprascrawler.http.HttpBot;
import br.com.sinerji.comprascrawler.util.FileUtil;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ArchivesFromPNCPCrawler extends PNCPArchivesCrawler {
    protected final File pagesDir;

    public ArchivesFromPNCPCrawler(Config config, HttpBot bot) {
        super(config, bot);
        this.pagesDir = config.getPncpEditalPagesDir(); // Diretório de arquivos JSON
        log.info("Diretório configurado para arquivos de editais: {}", this.pagesDir.getAbsolutePath());
    }

    @Override
    protected Set<PncpArchivesParams> getPncpArchivesParamsSet() {
        log.info("Iniciando extração de parâmetros de arquivos PNCP para editais...");
        Set<PncpArchivesParams> pncpArchivesParamsSet = new HashSet<>();
        List<File> pagesDirFiles = FileUtil.listDirFilesOrdered(pagesDir);

        log.info("Número total de arquivos encontrados no diretório: {}", pagesDirFiles.size());

        for (File pageFile : pagesDirFiles) {
            log.info("Processando arquivo: {}", pageFile.getName());
            String jsonStr = FileUtil.readFile(pageFile);

            try {
                JsonElement json = JsonParser.parseString(jsonStr);
                if (!json.isJsonObject()) {
                    log.warn("Formato de JSON inválido no arquivo: {}", pageFile.getName());
                    continue;
                }

                JsonObject dataObj = json.getAsJsonObject();
                JsonArray items = dataObj.getAsJsonArray("items");
                if (items == null || items.size() == 0) {
                    log.warn("Nenhum item encontrado no arquivo: {}", pageFile.getName());
                    continue;
                }

                log.info("Número de itens encontrados no arquivo {}: {}", pageFile.getName(), items.size());

                for (JsonElement item : items) {
                    if (!item.isJsonObject()) {
                        log.warn("Item inválido (não é um objeto JSON) no arquivo: {}", pageFile.getName());
                        continue;
                    }

                    JsonObject itemObj = item.getAsJsonObject();
                    String documentType = itemObj.has("document_type") ? itemObj.get("document_type").getAsString() : null;
                    String itemUrl = itemObj.has("item_url") ? itemObj.get("item_url").getAsString() : null;

                    log.debug("document_type: {}, item_url: {}", documentType, itemUrl);

                    // Verificar se o tipo de documento é "edital"
                    if (documentType == null || !"edital".equalsIgnoreCase(documentType)) {
                        log.debug("Tipo de documento não corresponde a 'edital' no arquivo: {}", pageFile.getName());
                        continue;
                    }

                    if (itemUrl == null || itemUrl.isEmpty()) {
                        log.warn("URL do item está ausente ou vazia no arquivo: {}", pageFile.getName());
                        continue;
                    }

                    // Extrair parâmetros ajustados para o formato correto
                    String[] split = itemUrl.split("/");
                    if (split.length < 5) {
                        log.warn("Formato de URL inválido (esperados pelo menos 5 segmentos): {}", itemUrl);
                        continue;
                    }

                    String largeCode = split[2]; // CNPJ do órgão
                    String year = split[3];      // Ano do edital
                    String smallCode = split[4]; // Código sequencial do edital

                    log.info("Parâmetros extraídos: largeCode={}, year={}, smallCode={}", largeCode, year, smallCode);

                    pncpArchivesParamsSet.add(PncpArchivesParams.builder()
                            .largeCode(largeCode)
                            .year(year)
                            .smallCode(smallCode)
                            .build());
                }
            } catch (Exception e) {
                log.error("Erro ao processar o arquivo {}: {}", pageFile.getName(), e.getMessage());
            }
        }

        log.info("Extração concluída. Total de parâmetros extraídos: {}", pncpArchivesParamsSet.size());
        return pncpArchivesParamsSet;
    }

    @Override
    protected String getTypeFilter() {
        return "edital"; // Filtro para buscar apenas editais
    }
}
