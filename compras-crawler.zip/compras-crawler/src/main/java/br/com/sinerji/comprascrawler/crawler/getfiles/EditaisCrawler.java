package br.com.sinerji.comprascrawler.crawler.getfiles;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.ClientProtocolException;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import br.com.sinerji.comprascrawler.Config;
import br.com.sinerji.comprascrawler.crawler.Crawler;
import br.com.sinerji.comprascrawler.crawler.CrawlerException;
import br.com.sinerji.comprascrawler.crawler.FetchChecker;
import br.com.sinerji.comprascrawler.http.HttpBot;
import br.com.sinerji.comprascrawler.util.FileUtil;
import br.com.sinerji.comprascrawler.util.Util;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditaisCrawler extends Crawler {
    private static final String ARCHIVE_TYPE_ATTR_NAME = "tipoDocumentoNome";
    private static final String ARCHIVE_URL_ATTR_NAME = "url";
    private static final String EDITAL_FILE_TYPE = "pdf";

    private final FetchChecker fetchChecker;
    private final File pncpArchivesDir;
    private final File editaisDir;

    public EditaisCrawler(Config config, HttpBot bot) {
        super(config, bot);
        this.pncpArchivesDir = config.getPncpArchivesDir();
        this.editaisDir = new File(config.getDataDir(), "editais"); // Diretório para salvar os editais
        FileUtil.createDirectoryIfNotExists(this.editaisDir);
        this.fetchChecker = new FetchChecker(config, "fetched_editais.txt"); // Rastreamento dos editais baixados
    }

    @Override
    protected void runCrawler() throws ClientProtocolException, IOException {
        List<File> pncpArchives = FileUtil.listDirFilesOrdered(pncpArchivesDir);
        List<EditalParams> editalUrls = getEditalParamsList(pncpArchives);
        int counter = fetchChecker.getNumOfFetchedFiles();

        for (EditalParams params : editalUrls) {
            String editalId = params.id();
            if (fetchChecker.contains(editalId)) {
                log.info("Edital já baixado: " + editalId);
                continue;
            }

            File targetFile = new File(editaisDir, String.format("%s.%s", editalId, EDITAL_FILE_TYPE));
            log.info("Baixando edital: " + editalId);
            bot.downloadFile(params.url(), targetFile.getAbsolutePath());
            fetchChecker.updateFetchedSetFile(editalId);
            counter++;

            if (counter % 20 == 0) {
                log.info(String.format("%d/%d baixados", counter, editalUrls.size()));
            }
        }
    }

    private List<EditalParams> getEditalParamsList(List<File> pncpArchives) {
        log.info("Extraindo URLs de editais dos arquivos de JSON...");
        List<EditalParams> editalUrls = new ArrayList<>();
        int counter = 0;

        for (File pncpArchivesFile : pncpArchives) {
            String jsonStr = FileUtil.readFile(pncpArchivesFile);
            JsonElement json = Util.parseLenientJsonString(jsonStr);
            EditalParams params = getParams(pncpArchivesFile, json);

            if (params != null) {
                editalUrls.add(params);
            }

            counter++;
            if (counter % 500 == 0) {
                log.info(String.format("%d/%d parâmetros extraídos", counter, pncpArchives.size()));
            }
        }
        return editalUrls;
    }

    private EditalParams getParams(File pncpArchivesFile, JsonElement json) {
        for (JsonElement archiveJson : json.getAsJsonArray()) {
            JsonObject archiveJsonObj = archiveJson.getAsJsonObject();

            if (!archiveJsonObj.has(ARCHIVE_TYPE_ATTR_NAME)) {
                throw new CrawlerException("O JSON do arquivo não contém o atributo: " + ARCHIVE_TYPE_ATTR_NAME);
            }

            String archiveType = archiveJsonObj.get(ARCHIVE_TYPE_ATTR_NAME).getAsString();
            if ("Edital".equalsIgnoreCase(archiveType)) {
                if (!archiveJsonObj.has(ARCHIVE_URL_ATTR_NAME)) {
                    throw new CrawlerException("O JSON do arquivo não contém o atributo: " + ARCHIVE_URL_ATTR_NAME);
                }

                String id = FileUtil.getFileNameWithoutExtension(pncpArchivesFile);
                String url = archiveJsonObj.get(ARCHIVE_URL_ATTR_NAME).getAsString();
                return new EditalParams(id, url);
            }
        }
        return null;
    }

    private record EditalParams(String id, String url) {}
}
