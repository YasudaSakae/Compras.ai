package br.com.sinerji.comprascrawler.crawler.getfiles;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.ClientProtocolException;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import br.com.sinerji.comprascrawler.Config;
import br.com.sinerji.comprascrawler.crawler.Crawler;
import br.com.sinerji.comprascrawler.crawler.FetchChecker;
import br.com.sinerji.comprascrawler.http.HttpBot;
import br.com.sinerji.comprascrawler.util.FileUtil;
import br.com.sinerji.comprascrawler.util.Util;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EditaisCrawler extends Crawler {
    private static final String ARCHIVE_TYPE_ATTR_NAME = "tipoDocumentoNome";
    private static final String ARCHIVE_URL_ATTR_NAME = "url";
    private static final String EDITAL_FILE_TYPE = "pdf";

    private final FetchChecker fetchChecker;
    private final File editaisDir;

    public EditaisCrawler(Config config, HttpBot bot) {
        super(config, bot);
        this.editaisDir = config.getEditaisDir();
        FileUtil.createDirectoryIfNotExists(editaisDir);
        this.fetchChecker = new FetchChecker(config, "fetched_editais.txt");
    }

    @Override
    protected void runCrawler() throws ClientProtocolException, IOException {
        List<File> jsonFiles = FileUtil.listDirFilesOrdered(editaisDir);

        if (jsonFiles.isEmpty()) {
            log.warn("Nenhum arquivo JSON encontrado no diretório: " + editaisDir.getAbsolutePath());
            return;
        }

        log.info("Arquivos JSON encontrados no diretório: " + editaisDir.getAbsolutePath());
        jsonFiles.forEach(file -> log.info("Arquivo encontrado: " + file.getName()));

        List<EditalParams> editalUrls = getEditalParamsList(jsonFiles);
        int counter = fetchChecker.getNumOfFetchedFiles();

        for (EditalParams params : editalUrls) {
            String editalId = params.id();
            if (fetchChecker.contains(editalId)) {
                log.info("Edital já baixado: " + editalId);
                continue;
            }

            File targetFile = new File(editaisDir, String.format("%s.%s", editalId, EDITAL_FILE_TYPE));
            log.info("Baixando edital: " + editalId);

            try {
                bot.downloadFile(params.url(), targetFile.getAbsolutePath());
                fetchChecker.updateFetchedSetFile(editalId);
                counter++;

                if (counter % 20 == 0) {
                    log.info(String.format("%d/%d editais baixados", counter, editalUrls.size()));
                }
            } catch (Exception e) {
                log.error("Erro ao baixar o edital {}: {}", editalId, e.getMessage());
            }
        }
    }

    private List<EditalParams> getEditalParamsList(List<File> jsonFiles) {
        log.info("Extraindo URLs de editais dos arquivos JSON...");
        List<EditalParams> editalUrls = new ArrayList<>();
        int counter = 0;

        for (File jsonFile : jsonFiles) {
            log.info("Processando arquivo: " + jsonFile.getName());
            String jsonStr = FileUtil.readFile(jsonFile);
            log.debug("Conteúdo do arquivo JSON (" + jsonFile.getName() + "): " + jsonStr);

            JsonElement json = Util.parseLenientJsonString(jsonStr);
            if (json == null) {
                log.error("Falha ao parsear JSON no arquivo: " + jsonFile.getName());
                continue;
            }

            if (json.isJsonArray()) {
                JsonArray jsonArray = json.getAsJsonArray();
                for (JsonElement archiveJson : jsonArray) {
                    EditalParams params = extractParams(archiveJson);
                    if (params != null) {
                        editalUrls.add(params);
                    }
                }
            } else {
                log.error("Formato de JSON inesperado no arquivo: " + jsonFile.getName());
                continue;
            }

            counter++;
            if (counter % 500 == 0) {
                log.info(String.format("%d/%d parâmetros extraídos", counter, jsonFiles.size()));
            }
        }
        return editalUrls;
    }

    private EditalParams extractParams(JsonElement archiveJson) {
        JsonObject archiveJsonObj = archiveJson.getAsJsonObject();
        log.debug("JSON processado: " + archiveJsonObj.toString());

        String url = archiveJsonObj.has(ARCHIVE_URL_ATTR_NAME)
                ? archiveJsonObj.get(ARCHIVE_URL_ATTR_NAME).getAsString()
                : null;

        if (url == null) {
            log.warn("Nenhum URL válido encontrado no JSON: " + archiveJsonObj);
            return null;
        }

        String id = String.format("%s-%s-%s",
                archiveJsonObj.get("cnpj").getAsString(),
                archiveJsonObj.get("sequencialCompra").getAsString(),
                archiveJsonObj.get("anoCompra").getAsString());

        log.info("Parâmetro válido encontrado: id=" + id + ", url=" + url);
        return new EditalParams(id, url);
    }

    private record EditalParams(String id, String url) {}
}
