-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('DISTRITO FEDERAL', 'SEFJ', '33.861.706/0001-05')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('MCR SISTEMAS E CONSULTORIA LTDA', '04.198.254/0001-17')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '23/2024',
        'Contrato de Prestação de Serviços',
        '04043-00000395/2024-81',
        NULL,
        'Contrato',
        '23/2024',
        's3://compras-ia-np/Contratos/00394684000153-000078-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '33.861.706/0001-05' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '04.198.254/0001-17' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '23/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000078-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '23/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000078-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Licenças de uso do Software Adobe Creative Cloud VIP Teams All Apps, com licenciamento subscrição por usuário nomeado, em sua versão mais recente e com serviço de suporte técnico e garantia de atualização pelo período de 12 (doze) meses.',
    'Marca/Fabricante: Adobe System. Modelo: Creative Cloud.',
    'unidade',
    '01',
    'R$ 4.828,00',
    'R$ 4.828,00',
    '27502',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
;