-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('DISTRITO FEDERAL', 'VGDF', '07.187.000/0001-91')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('INSTITUTO NEGÓCIOS PÚBLICOS DO BRASIL - ESTUDOS E PESQUISAS NA ADMINISTRAÇÃO PÚBLICA - INP - LTDA', '10.498.974/0002-81')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '30/2024',
        'Contrato de Prestação de Serviço',
        '04043-00001037/2024-95',
        NULL,
        'Contrato',
        '30/2024',
        's3://compras-ia-np/Contratos/00394684000153-000108-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '07.187.000/0001-91' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '10.498.974/0002-81' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '30/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000108-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '30/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000108-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Contratação de empresa especializada na prestação de serviços de capacitação, visando a participação de servidores lotados na Subsecretaria de Administração Geral da Vice-Governadoria do Distrito Federal (SUAG/VGDF) no 4º Seminário Nacional de Controle Interno nas Contratações Públicas, no período de 23 a 25 de setembro de 2024.',
    '',
    'Unidade',
    '02',
    'R$ 4.490,00',
    'R$ 8.980,00',
    '14729',
    'Serviço',
    'Foz do Iguaçu (PR)'
FROM contrato_id
;