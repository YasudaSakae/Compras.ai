-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('DISTRITO FEDERAL, por intermédio da SECRETARIA DE ESTADO DE SAÚDE', 'SES/DF', '00.394.700/0001-08')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('BHIOS PRODUTOS E SERVICOS PARA APOIO CLINICO LTDA', '22.666.117/0001-41')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '052748/2024',
        'Contrato Administrativo',
        '00060-00288007/2021-62',
        TO_DATE('04/11/2024', 'DD/MM/YYYY'),
        'Contrato',
        '052748/2024',
        's3://compras-ia-np/Contratos/00394700000108-000029-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.394.700/0001-08' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '22.666.117/0001-41' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '052748/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394700000108-000029-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '052748/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394700000108-000029-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Contratação de empresa especializada em prestação de serviços de Manutenção preventiva e corretiva com reposição de peças de 21 (vinte e um) Perfuradores Ortopédicos, marca TECNOAR',
    'Manutenção preventiva e corretiva com reposição de peças de 21 (vinte e um) Perfuradores Ortopédicos, marca TECNOAR',
    'UNIDADE',
    '21',
    'R$ 826,88',
    'R$ 208.373,76',
    '5428',
    'Serviço',
    'HRS (DF), HRPL (DF), HRC (DF), HRG (DF), HRL (DF), HRT (DF)'
FROM contrato_id
;