-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('FUNDAÇÃO HEMOCENTRO DE BRASÍLIA', 'FHB', '86.743.457/0001-01')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('LMX DO BRASIL COMÉRCIO DE UTILIDADES LTDA', '23.904.788/0001-66')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '028/2023',
        'Contrato',
        '00063-00004797/2023-11',
        NULL,
        'Contrato',
        '028/2023',
        's3://compras-ia-np/Contratos/00394684000153-000031-2023.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '86.743.457/0001-01' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '23.904.788/0001-66' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '028/2023'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000031-2023.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '028/2023'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000031-2023.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Fabricação e instalação de uma cobertura fixa para vaga de estacionamento (ônibus)',
    'Reta, estrutura em aço carbono, pintura eletrostática na cor branca, revestimento em LONA SINTETICA IMPERMEAVEL. Dimensões: - MODELO RETANGULAR 16m x 5m x 5,5m (altura); - Área total de cobertura = 80m². Especificações da estrutura metálica: - Colunas , tubo de 5”#13 (somente na parte posterior); - Quadro da projeção, tubo 70X30#18; - Travessas, tubo 50X30#18. Especificações das bases: - Aço concretado em base com medidas mínimas de 1m de altura x 0,60 cm x 0,60 cm. Especificações das telas (coberturas): - Lona sintética impermeável de cor a escolha, gramatura 220g , fabricada em polietileno de alta densidade, com aditivos especiais que a torne altamente durável contra raios UV e com grande resistência mecânica.',
    'Serviço',
    '1',
    'R$21.000,00',
    'R$21.000,00',
    '17809',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
;