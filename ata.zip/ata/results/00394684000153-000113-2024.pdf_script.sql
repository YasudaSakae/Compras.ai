-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('DISTRITO FEDERAL', 'VGDF', '07.187.000/0001-91')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('CASA ATIVA LTDA', '15.200.867/0001-68')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '34/2024',
        'Contrato',
        '04043-00000558/2024-25',
        NULL,
        'Contrato',
        '34/2024',
        's3://compras-ia-np/Contratos/00394684000153-000113-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '07.187.000/0001-91' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '15.200.867/0001-68' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '34/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000113-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '34/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000113-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Fogão industrial em aço inox',
    'Fogão industrial em aço inox, 90cm, 6 bocas. Especificações técnicas mínimas: Queimadores superiores 5 grandes e um pequeno e grelhas de ferro fundido com acabamento esmaltado a fogo Revestimento externo em aço inoxidável Acendimento automático elétrico para todos os queimadores Forno de alto rendimento, com capacidade de aquecimento de até 300°C. Modelo/qualidade similar ao fogão Don Bidone Venâncio ou superior. Garantia: 1 ano.',
    'Unidade',
    '1',
    'R$ 6.130,81',
    'R$ 6.130,81',
    '451454',
    'Material',
    'LAGO SUL (DF)'
FROM contrato_id
;