-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('DISTRITO FEDERAL', 'VGDF', '07.187.000/0001-91')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('39.805.124 RAFAEL LIMA DINIZ', '39.805.124/0001-80')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '16/2024',
        'Contrato',
        '04043-00000298/2024-98',
        TO_DATE('24/04/2024', 'DD/MM/YYYY'),
        'Contrato',
        '16/2024',
        's3://compras-ia-np/Contratos/00394684000153-000041-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '07.187.000/0001-91' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '39.805.124/0001-80' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '16/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000041-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '16/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000041-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Aparelho de Jantar Branco com 42 peças',
    'Composto por: 06 pratos rasos; 06 pratos fundos; 06 pratos para sobremesa; 06 xícaras para café e 06 pires; e 06 xícaras para chá e 06 pires',
    'UN',
    '5',
    'R$ 890,00',
    'R$ 4.450,00',
    '605224',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Faqueiro com 30 peças',
    'Composto por: 06 colheres de mesa 06 garfos de mesa 06 facas de mesa 06 garfos de bolo 06 colheres de chá.',
    'UN',
    '5',
    'R$ 337,15',
    'R$ 1.685,75',
    '294447',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Jogo facas com 5 peças',
    'Composto por: 01 Faca do Chef; 01 Faca de Pão; 01 Faca de Legumes; 01 Faca de filetar; O1 Faca de serra;',
    'UN',
    '2',
    'R$ 337,00',
    'R$ 674,00',
    '387118',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Jogo faca para Churrasco com 5 peças – cabo madeira',
    'Composto por: 01 faca de faar 01 faca Butcher 01 faca churrasco 01 faca desossa 01 Cutelo',
    'UN',
    '1',
    'R$ 399,00',
    'R$ 399,00',
    '387118',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Conjunto 6 Bowls para sobremesa porcelana branca',
    '',
    'UN',
    '5',
    'R$ 125,93',
    'R$ 629,65',
    '482839',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Jogo de utensílios cozinha com 5 peças',
    'Composto por: 01 Colher para arroz 01 Concha para feijão 01 Garfo trinchante 01 Pegador para massa 01 Pá para bolo',
    'UN',
    '2',
    'R$ 146,10',
    'R$ 292,20',
    '256304',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Rechaud Oval de Porcelana branca 1,5L',
    '',
    'UN',
    '4',
    'R$ 240,00',
    'R$ 960,00',
    '473232',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Rechaud Retangular de porcelana branca 2,8L',
    '',
    'UN',
    '4',
    'R$ 356,32',
    'R$ 1.425,28',
    '473232',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Travessa de Cerâmica Medidas: 36 X 24,5 Cm',
    '',
    'UN',
    '4',
    'R$ 130,00',
    'R$ 520,00',
    '219098',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Saladeira Cerâmica 2,5L',
    '',
    'UN',
    '2',
    'R$ 149,00',
    'R$ 298,00',
    '259244',
    'Material',
    'Brasília (DF)'
FROM contrato_id
;