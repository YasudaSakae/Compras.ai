-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('LABORATÓRIO FEDERAL DE DEFESA AGROPECUÁRIA – LFDA-SP', 'LFDA-SP', '00.396.895/0047-08')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('LOBO V CIENTIFICA , IMPORTACAO, EXPORTACAO, COMERCIO DE EQUIPAMENTOS PARA LABORATORIOS LTDA', '05.857.218/0001-80')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '038/2023',
        'Contrato',
        '21053.000236/2023-03',
        TO_DATE('18/07/2023', 'DD/MM/YYYY'),
        'Contrato',
        '038/2023',
        's3://compras-ia-np/Contratos/00396895000125-000209-2023.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0047-08' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '05.857.218/0001-80' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '038/2023'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000209-2023.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '038/2023'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000209-2023.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Manutenção corretiva, serviço técnico',
    'Contratação de serviço de manutenção corretiva da lavadora SMEG GW4090, número de série 1032200052, o serviço técnico necessário para colocação da lavadora em pleno funcionamento. A manutenção será feita na própria LOBOV, autorizada pela SMEG no Brasil. valor referente ao serviço técnico',
    'UNIDADE',
    '1',
    'R$ 2.300,00',
    'R$ 2.300,00',
    '16314',
    'Serviço',
    'São Paulo (SP)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Fornecimento de Peças',
    'Lavadora SMEG GW4090, número de série 1032200052, incluindo a substituição do Pressostato de nível P/N 816210419:
Relação de peças a serem fornecidas para execução do serviço:
* 816210419- Pressostato de nível para mod. GW4060/4090',
    'UNIDADE',
    '1',
    'R$ 980,88',
    'R$ 980,88',
    '603701',
    'Material',
    'São Paulo (SP)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Fornecimento de Peças',
    'Lavadora SMEG GW4090, número de série 1032200052, incluindo a substituição Bomba de circulação P/N 695210956:
Relação de peças a serem fornecidas para execução do serviço:
* 695210956 - Bomba de circulação para mod. GW4060/4090',
    'UNIDADE',
    '1',
    'R$3.407,25',
    'R$3.407,25',
    '415030',
    'Material',
    'São Paulo (SP)'
FROM contrato_id
;