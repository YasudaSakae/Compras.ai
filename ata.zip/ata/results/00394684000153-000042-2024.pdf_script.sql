-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('DISTRITO FEDERAL', 'VGDF', '07.187.000/0001-91')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('JLIRIC COMERCIO DE ARTIGOS DE DECORAÇÃO DE MESA LTDA', '25.244.227/0001-03')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '17/2024',
        'Contrato',
        '04043-00000298/2024-98',
        TO_DATE('24/04/2024', 'DD/MM/YYYY'),
        'Contrato',
        '17/2024',
        's3://compras-ia-np/Contratos/00394684000153-000042-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '07.187.000/0001-91' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '25.244.227/0001-03' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '17/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000042-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '17/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000042-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Sousplat de plástico com 2 cm de altura, 0.34 kg e diâmetro de 33 cm, cor verde qualidade semelhante a home style ou superior',
    'Sousplat de plástico com 2 cm de altura, 0.34 kg e diâmetro de 33 cm, cor verde qualidade semelhante a home style ou superior',
    'UN',
    '15',
    'R$ 20,99',
    'R$ 314,85',
    '466017',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Sousplat de plástico com 2 cm de altura, 0.34 kg e diâmetro de 33 cm, cor azul qualidade semelhante a home style ou superior',
    'Sousplat de plástico com 2 cm de altura, 0.34 kg e diâmetro de 33 cm, cor azul qualidade semelhante a home style ou superior',
    'UN',
    '15',
    'R$ 20,99',
    'R$ 341,85',
    '466017',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Guardanapos de tecido 100% algodão, cor branca 11x22 cm;',
    'Guardanapos de tecido 100% algodão, cor branca 11x22 cm;',
    'UN',
    '30',
    'R$ 8,99',
    'R$ 269,70',
    '450174',
    'Material',
    'Brasília (DF)'
FROM contrato_id
;