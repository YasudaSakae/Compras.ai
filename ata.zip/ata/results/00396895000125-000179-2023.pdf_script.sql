-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('INSTITUTO NACIONAL DE METEOROLOGIA', 'INMET', '00.396.895/0010-16')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('MB APOIO E SERVICOS LTDA', '41.106.296/0001-07')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '26/2023',
        'Contrato',
        '21166.000273/2022-55',
        NULL,
        'Contrato',
        '26/2023',
        's3://compras-ia-np/Contratos/00396895000125-000179-2023.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0010-16' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '41.106.296/0001-07' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '26/2023'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000179-2023.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '26/2023'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000179-2023.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Monitoramento Eletrônico com Fornecimento de Equipamentos em Comodato para a Estação Meteorológica de Petrolina - PE',
    '',
    'Meses',
    '12',
    'R$ 635,00',
    'R$ 7.620,00',
    '14826',
    'Serviço',
    'Petrolina (PE)'
FROM contrato_id
;