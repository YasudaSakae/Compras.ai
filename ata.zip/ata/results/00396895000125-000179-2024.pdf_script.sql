-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('LABORATÓRIO FEDERAL DE DEFESA AGROPECUÁRIA – LFDA/RS', 'LFDA/RS', '00.396.895/0045-46')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('AGILENT TECHNOLOGIES BRASIL LTDA.', '03.290.250/0006-06')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '7/2024',
        'Contrato',
        '21043.001058/2023-49',
        TO_DATE('22/12/2017', 'DD/MM/YYYY'),
        'Contrato',
        '7/2024',
        's3://compras-ia-np/Contratos/00396895000125-000179-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0045-46' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '03.290.250/0006-06' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '7/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000179-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '7/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000179-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Manutenção preventiva em sistema de espectrometria de massa com plasma indutivamente acoplado (ICP-MS), marca Agilent composto pelos módulos: ICP-MS modelo 7900, número de série JP16031267; autoamostrador modelo SPS4 Autosampler, número de série AU15490939; chiller modelo G3292-80200, número de série 1908-02200; respectivos softwares de aquisição e tratamento de dados.',
    'ICP-MS modelo 7900, número de série JP16031267; autoamostrador modelo SPS4 Autosampler, número de série AU15490939; chiller modelo G3292-80200, número de série 1908-02200; respectivos softwares de aquisição e tratamento de dados.',
    'Serviço',
    '2',
    'R$ 31.725,57',
    'R$ 63.451,14',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Qualificação operacional em sistema de espectrometria de massa com plasma indutivamente acoplado (ICP-MS), marca Agilent composto pelos módulos: ICP-MS modelo 7900, número de série JP16031267; autoamostrador modelo SPS4 Autosampler, número de série AU15490939; chiller modelo G3292-80200, número de série 1908-02200; respectivos softwares de aquisição e tratamento de dados.',
    'ICP-MS modelo 7900, número de série JP16031267; autoamostrador modelo SPS4 Autosampler, número de série AU15490939; chiller modelo G3292-80200, número de série 1908-02200; respectivos softwares de aquisição e tratamento de dados.',
    'Serviço',
    '2',
    'R$ 18.911,26',
    'R$ 37.822,52',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Manutenção preventiva em sistema de cromatografia líquida (HPLC), marca Agilent composto pelos módulos: Forno de coluna modelo 1260 Thermostated Column Compartment, número de série DEACN42772; autoamostrador modelo 1260 Standard Autosampler, número de série DEAAC25890; degaseificador modelo 1260 Infinity HighPerformance Degasser, número de série JPAAB06777; bomba binária modelo 1260 Binary Pump, número de série DEADT10511; respectivos softwares de aquisição e tratamento de dados.',
    'Forno de coluna modelo 1260 Thermostated Column Compartment, número de série DEACN42772; autoamostrador modelo 1260 Standard Autosampler, número de série DEAAC25890; degaseificador modelo 1260 Infinity HighPerformance Degasser, número de série JPAAB06777; bomba binária modelo 1260 Binary Pump, número de série DEADT10511; respectivos softwares de aquisição e tratamento de dados.',
    'Serviço',
    '2',
    'R$ 13.870,43',
    'R$ 27.740,86',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Qualificação operacional em sistema de cromatografia líquida (HPLC), marca Agilent composto pelos módulos: Forno de coluna modelo 1260 Thermostated Column Compartment, número de série DEACN42772; autoamostrador modelo 1260 Standard Autosampler, número de série DEAAC25890; degaseificador modelo 1260 Infinity HighPerformance Degasser, número de série JPAAB06777; bomba binária modelo 1260 Binary Pump, número de série DEADT10511; respectivos softwares de aquisição e tratamento de dados.',
    'Forno de coluna modelo 1260 Thermostated Column Compartment, número de série DEACN42772; autoamostrador modelo 1260 Standard Autosampler, número de série DEAAC25890; degaseificador modelo 1260 Infinity HighPerformance Degasser, número de série JPAAB06777; bomba binária modelo 1260 Binary Pump, número de série DEADT10511; respectivos softwares de aquisição e tratamento de dados.',
    'Serviço',
    '2',
    'R$ 15.529,62',
    'R$ 31.059,24',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Manutenção preventiva em sistema de espectrometria de massa com plasma indutivamente acoplado (ICP-MS), marca Agilent composto pelos módulos: ICP-MS modelo 7700x, número de série JP12081598; sistema integrado de introdução de amostras modelo ISIS, número de série JP12100165; autoamostrador modelo Integrated autosampler, número de série DE80902049; chiller modelo PSC 6106T Chiller, número de série 4N1220054; respectivos softwares de aquisição e tratamento de dados.',
    'ICP-MS modelo 7700x, número de série JP12081598; sistema integrado de introdução de amostras modelo ISIS, número de série JP12100165; autoamostrador modelo Integrated autosampler, número de série DE80902049; chiller modelo PSC 6106T Chiller, número de série 4N1220054; respectivos softwares de aquisição e tratamento de dados.',
    'Serviço',
    '2',
    'R$ 34.260,27',
    'R$ 68.520,54',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Qualificação operacional em sistema de espectrometria de massa com plasma indutivamente acoplado (ICP-MS), marca Agilent composto pelos módulos: ICP-MS modelo 7700x, número de série JP12081598; sistema integrado de introdução de amostras modelo ISIS, número de série JP12100165; autoamostrador modelo Integrated autosampler, número de série DE80902049; chiller modelo PSC 6106T Chiller, número de série 4N1220054; respectivos softwares de aquisição e tratamento de dados.',
    'ICP-MS modelo 7700x, número de série JP12081598; sistema integrado de introdução de amostras modelo ISIS, número de série JP12100165; autoamostrador modelo Integrated autosampler, número de série DE80902049; chiller modelo PSC 6106T Chiller, número de série 4N1220054; respectivos softwares de aquisição e tratamento de dados.',
    'Serviço',
    '2',
    'R$ 22.077,59',
    'R$ 44.155,18',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Manutenção preventiva em sistema de cromatografia gasosa acoplado à espectrometria de massas (GC-MS/MS), marca Agilent composto pelos módulos: cromatógrafo gasoso modelo Agilent 7890A Series GC, número de série CN11471115, espectrômetro de massas modelo 7000B EI/CI, número de série US11456705; autoamostrador modelo 7693A, números de série CN11460162; injetor modelo 7693A Autoinjector, números de série CN11430192; respectivos softwares de aquisição e tratamento de dados.',
    'cromatógrafo gasoso modelo Agilent 7890A Series GC, número de série CN11471115, espectrômetro de massas modelo 7000B EI/CI, número de série US11456705; autoamostrador modelo 7693A, números de série CN11460162; injetor modelo 7693A Autoinjector, números de série CN11430192; respectivos softwares de aquisição e tratamento de dados.',
    'Serviço',
    '2',
    'R$ 19.306,16',
    'R$ 38.612,32',
    '16314',
    'Serviço',
    'São José (SC)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Qualificação operacional em sistema de cromatografia gasosa acoplado à espectrometria de massas (GC-MS/MS), marca Agilent composto pelos módulos: cromatógrafo gasoso modelo Agilent 7890A Series GC, número de série CN11471115, espectrômetro de massas modelo 7000B EI/CI, número de série US11456705; autoamostrador modelo 7693A, números de série CN11460162; injetor modelo 7693A Autoinjector, números de série CN11430192; respectivos softwares de aquisição e tratamento de dados.',
    'cromatógrafo gasoso modelo Agilent 7890A Series GC, número de série CN11471115, espectrômetro de massas modelo 7000B EI/CI, número de série US11456705; autoamostrador modelo 7693A, números de série CN11460162; injetor modelo 7693A Autoinjector, números de série CN11430192; respectivos softwares de aquisição e tratamento de dados.',
    'Serviço',
    '2',
    'R$ 41.074,56',
    'R$ 82.149,12',
    '16314',
    'Serviço',
    'São José (SC)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Manutenção preventiva em eletroforese capilar marca Agilent modelo 7100 Capillary Electrophoresis, número de série DE32400878; respectivos softwares de aquisição e tratamento de dados.',
    'Agilent modelo 7100 Capillary Electrophoresis, número de série DE32400878; respectivos softwares de aquisição e tratamento de dados.',
    'Serviço',
    '2',
    'R$ 15.856,15',
    'R$ 31.712,30',
    '16314',
    'Serviço',
    'São José (SC)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Qualificação operacional em eletroforese capilar marca Agilent modelo 7100 Capillary Electrophoresis, número de série DE32400878; respectivos softwares de aquisição e tratamento de dados.',
    'Agilent modelo 7100 Capillary Electrophoresis, número de série DE32400878; respectivos softwares de aquisição e tratamento de dados.',
    'Serviço',
    '2',
    'R$ 15.229,62',
    'R$ 30.459,24',
    '16314',
    'Serviço',
    'São José (SC)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Despesas de viagem para atendimentos por técnico em São José-SC e Porto Alegre-RS.',
    'Despesas de viagem',
    'Serviço',
    '14',
    'R$ 3.661,23',
    'R$ 51.257,22',
    '16314',
    'Serviço',
    'São José (SC), Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Hora técnica para atendimentos de manutenção corretiva (low-end).',
    'Manutenção corretiva (low-end)',
    'Serviço',
    '80',
    'R$ 731,63',
    'R$ 58.530,40',
    '16314',
    'Serviço',
    'São José (SC), Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Hora técnica para atendimentos de manutenção corretiva (high-end).',
    'Manutenção corretiva (high-end)',
    'Serviço',
    '120',
    'R$ 860,21',
    'R$ 103.225,20',
    '16314',
    'Serviço',
    'São José (SC), Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Valor destinado a aplicação de peças e/ou consumíveis.',
    'Peças e/ou consumíveis',
    'Serviço',
    '2',
    'R$ 500.000,00',
    'R$ 1.000.000,00',
    '453625',
    'Serviço',
    'São José (SC), Porto Alegre (RS)'
FROM contrato_id
;