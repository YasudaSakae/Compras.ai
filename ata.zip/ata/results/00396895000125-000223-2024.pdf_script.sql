-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('LABORATÓRIO DE DEFESA AGROPECUÁRIA - LFDA/RS', 'LFDA/RS', '00.396.895/0045-46')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('VALOR EMPRESA DE SERVICOS LTDA', '14.932.346/0001-32')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '06/2024',
        'Contrato',
        '21043.000398/2023-52',
        TO_DATE('22/12/2017', 'DD/MM/YYYY'),
        'Contrato',
        '06/2024',
        's3://compras-ia-np/Contratos/00396895000125-000223-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0045-46' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '14.932.346/0001-32' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '06/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000223-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '06/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000223-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Secretário Executivo',
    '',
    'Posto',
    '1',
    'R$ 746.628,00',
    'R$ 746.628,00',
    '16578',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
;