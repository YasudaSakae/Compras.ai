-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('Superintendência de Agricultura e Pecuária em Minas Gerais', 'SFA-MG', '00.396.895/0026-83')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('SEGEX SEGURANÇA PRIVADA LTDA', '12.751.850/0001-00')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '8/2024',
        'Contrato',
        '21028.003247/2024-25',
        TO_DATE('01/07/2024', 'DD/MM/YYYY'),
        'Contrato',
        '8/2024',
        's3://compras-ia-np/Contratos/00396895000125-000207-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0026-83' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '12.751.850/0001-00' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '8/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000207-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '8/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000207-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Vigilante Armado Diurno 12x36',
    'Posto',
    'Posto',
    '2',
    'R$ 13.500,00',
    'R$ 27.000,00',
    '24015',
    'Serviço',
    'Belo Horizonte (MG)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Vigilante Armado Noturno 12x36',
    'Posto',
    'Posto',
    '2',
    'R$ 16.000,00',
    'R$ 32.000,00',
    '24015',
    'Serviço',
    'Belo Horizonte (MG)'
FROM contrato_id
;