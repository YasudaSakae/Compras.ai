-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('Distrito Federal, por intermédio do GABINETE DA VICE-GOVERNADORA DO DISTRITO FEDERAL', 'VGDF', '07.187.000/0001-91')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('TEODORO DOS SANTOS COMERCIAL LTDA', '45.997.371/0001-28')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '1/2024',
        'Contrato de Aquisição de Bens',
        '00014-00001404/2023-75',
        TO_DATE('25/01/2024', 'DD/MM/YYYY'),
        'Contrato',
        '1/2024',
        's3://compras-ia-np/Contratos/00394684000153-000014-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '07.187.000/0001-91' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '45.997.371/0001-28' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '1/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000014-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '1/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000014-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Travesseiro suporte firme',
    'com revestimento em percal 180 fios, 100% algodão',
    'Unidade',
    '12',
    'R$ 40,00',
    'R$ 480,00',
    '607597',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Capa protetora de travesseiro',
    'cor branca, com zipper e malha impermeável, TAMANHO 50 X 70cm, cor branca',
    'Unidade',
    '12',
    'R$ 14,00',
    'R$ 168,00',
    '452419',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Capa protetora para colchão queen',
    'cor branca, tamanho padrão queen, com malha impermeável, TAMANHO1.60x1.98m, cor branca, em algodão',
    'Unidade',
    '2',
    'R$ 100,00',
    'R$ 200,00',
    '445547',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Capa protetora para colchão casal',
    'cor branca, tamanho padrão casal, com malha impermeável',
    'Unidade',
    '1',
    'R$ 83,00',
    'R$ 83,00',
    '445547',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Jogo de toalhas com 4 peças',
    'cor branca, em algodão, Composto por 05 peças, sendo: 02 toalhas de banho, 02 toalhas de rosto e 01 toalha de piso',
    'Unidade',
    '3',
    'R$ 130,00',
    'R$ 390,00',
    '606421',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
;