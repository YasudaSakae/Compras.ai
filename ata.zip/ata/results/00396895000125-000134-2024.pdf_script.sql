-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('MINISTÉRIO DA AGRICULTURA E PECUÁRIA', 'MAPA', '00.396.895/0011-05')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('MSTUR TRANSPORTES E SERVIÇOS EIRELI', '21.998.504/0001-12')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '11/2024',
        'Contrato de Prestação de Serviços',
        '21000.072525/2023-11',
        NULL,
        'Contrato',
        '11/2024',
        's3://compras-ia-np/Contratos/00396895000125-000134-2024.pdf',
        'Parcial',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0011-05' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '21.998.504/0001-12' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '11/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000134-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '11/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000134-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Serviço de locação de veículos, com motorista, para transporte de delegados e autoridades brasileiras e estrangeiras que participarão da REUNIÃO DE GRUPO DE TRABALHO NO G20, do Ministério da Agricultura e Pecuária - MAPA (UASG 130005).',
    '',
    'Serviço',
    '1',
    'R$ 180.000,00',
    '',
    '4014',
    'Serviço',
    ''
FROM contrato_id
UNION ALL
SELECT

    id,
    'Serviço de locação de veículos, com motorista, para transporte de delegados e autoridades brasileiras e estrangeiras que participarão da REUNIÃO MINISTERIAL NO G20, do Ministério da Agricultura e Pecuária - MAPA (UASG 130005).',
    '',
    'Serviço',
    '1',
    'R$ 385.000,00',
    '',
    '4014',
    'Serviço',
    ''
FROM contrato_id
;