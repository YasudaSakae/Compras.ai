-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('FUNDAÇÃO HEMOCENTRO DE BRASÍLIA', 'FHB', '86.743.457/0001-01')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('BIOMETRIX DIAGNÓSTICA LTDA.', '06.145.976/0001-39')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '026/2023',
        'Contrato',
        '00063-00004628/2023-81',
        NULL,
        'Contrato',
        '026/2023',
        's3://compras-ia-np/Contratos/00394684000153-000027-2023.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '86.743.457/0001-01' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '06.145.976/0001-39' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '026/2023'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000027-2023.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '026/2023'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000027-2023.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'KIT COMPLETO PARA TIPAGEM DE ANTÍGENOS LEUCOCITÁRIOS HUMANOS LOCUS DQA1 e DQB1',
    'por sondas oligonucleotídicas específicas para avaliação de histocompatibilidade para transplante por citometria de fluxo',
    'Teste',
    '800',
    'R$408,80',
    'R$327.040,00',
    '484163',
    'Material',
    'Brasília (DF)'
FROM contrato_id
;