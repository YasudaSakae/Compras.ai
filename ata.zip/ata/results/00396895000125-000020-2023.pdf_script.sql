-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('MINISTÉRIO DA AGRICULTURA E PECUÁRIA', 'MAPA', '00.396.895/0045-46')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('LIFE TECHNOLOGIES BRASIL COMÉRCIO E INDÚSTRIA DE PRODUTOS PARA BIOTECNOLOGIA LTDA', '63.067.904/0002-35')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '01/2023',
        'Contrato',
        '21043.001331/2022-54',
        TO_DATE('12/09/2023', 'DD/MM/YYYY'),
        'Contrato',
        '01/2023',
        's3://compras-ia-np/Contratos/00396895000125-000020-2023.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0045-46' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '63.067.904/0002-35' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '01/2023'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000020-2023.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '01/2023'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000020-2023.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Manutenção preventiva (AB Maintenance 1PM) em sistema RT-PCR, modelo 7500 Real Time PCR System, número de série 275002110, marca Applied Biosystems',
    '',
    'Serviço',
    '1',
    'R$ 12.921,13',
    'R$ 12.921,13',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Qualificação operacional (Add On Qualificação) em sistema RT-PCR, modelo 7500 Real Time PCR System, número de série 275002110, marca Applied Biosystems',
    '',
    'Serviço',
    '1',
    'R$ 30.121,47',
    'R$ 30.121,47',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Calibração (Add On Calibração) em sistema RT-PCR, modelo 7500 Real Time PCR System, número de série 275002110, marca Applied Biosystems',
    '',
    'Serviço',
    '1',
    'R$ 13.209,10',
    'R$ 13.209,10',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Manutenção preventiva (AB Maintenance 1PM) em sistema RT-PCR, modelo QuantStudio 3, número de série 272322196, marca Applied Biosystems',
    '',
    'Serviço',
    '1',
    'R$ 13.757,81',
    'R$ 13.757,81',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Qualificação operacional (Add On Qualificação em sistema RT-PCR, modelo QuantStudio 3, número de série 272322196, marca Applied Biosystems',
    '',
    'Serviço',
    '1',
    'R$ 39.338,45',
    'R$ 39.338,45',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Manutenção preventiva (Add On Calibração) em sistema RT-PCR, modelo QuantStudio 3, número de série 272322196, marca Applied Biosystems',
    '',
    'Serviço',
    '1',
    'R$ 9.344,94',
    'R$ 9.344,94',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Manutenção preventiva (AB Maintenance 1PM) em sistema RT-PCR, modelo QuantStudio 3, número de série 272322230, marca Applied Biosystems',
    '',
    'Serviço',
    '1',
    'R$ 13.757,81',
    'R$ 13.757,81',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Qualificação operacional (Add On Qualificação em sistema RT-PCR, modelo QuantStudio 3, número de série 272322230, marca Applied Biosystems',
    '',
    'Serviço',
    '1',
    'R$ 39.338,45',
    'R$ 39.338,45',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Manutenção preventiva (Add On Calibração) em sistema RT-PCR, modelo QuantStudio 3, número de série 272322230, marca Applied Biosystems',
    '',
    'Serviço',
    '1',
    'R$ 9.344,94',
    'R$ 9.344,94',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Manutenção preventiva (AB Maintenance 1PM) em espectrofotômetro, modelo NanoDrop Série 2000C, número de série AZY1811540, marca Thermo Fisher Scientific',
    '',
    'Serviço',
    '1',
    'R$ 10.253,78',
    'R$ 10.253,78',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Manutenção preventiva (AB Maintenance 1PM) em sistema automatizado de extração de ácidos nucleicos, modelo King Fisher Flex, número de série 711-2345, marca Thermo Fisher Scientific',
    '',
    'Serviço',
    '1',
    'R$ 12.444,00',
    'R$ 12.444,00',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Qualificação operacional (AB Maintenance 1PM) em sistema automatizado de extração de ácidos nucleicos, modelo King Fisher Flex, número de série 711-2345, marca Thermo Fisher Scientific',
    '',
    'Serviço',
    '1',
    'R$ 18.845,71',
    'R$ 18.845,71',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Horas técnicas destinadas à manutenções corretivas. Será considerado o montante de 50 horas técnicas, sendo este quantitativo apenas estimado, pago sob demanda, e prevendo cenários atípicos de manutenção.',
    '',
    'Serviço',
    '50',
    'R$ 579,33',
    'R$ 28.966,50',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Custos de deslocamento para atendimento de manutenções corretivas. Será considerado o montante de 5 chamados anuais, sendo este quantitativo apenas estimado, pago sob demanda, e prevendo cenários atípicos de manutenção.',
    '',
    'Deslocamento',
    '5',
    'R$ 3.623,22',
    'R$ 18.116,10',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
;