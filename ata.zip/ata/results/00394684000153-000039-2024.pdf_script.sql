-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('DISTRITO FEDERAL, POR INTERMÉDIO DA VICE-GOVERNADORIA DO DISTRITO FEDERAL', 'VGDF', '07.187.000/0001-91')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('SILVENINA UNIFORMES LTDA EPP', '18.386.337/0001-44')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '14/2024',
        'Contrato',
        '04043-00000297/2024-43',
        NULL,
        'Contrato',
        '14/2024',
        's3://compras-ia-np/Contratos/00394684000153-000039-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '07.187.000/0001-91' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '18.386.337/0001-44' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '14/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000039-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '14/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000039-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Tapete branco em algodão 100% POLIÉSTER. Medida: 50x80cm. Qualidade mmartan ou superior.',
    'Tapete branco em algodão 100% POLIÉSTER. Medida: 50x80cm. Qualidade mmartan ou superior.',
    'UN',
    '3',
    'R$ 166,43',
    'R$ 499,29',
    '472933',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Almofada em tricot 30 x 30, Gramatura: 100grs/m², Tipo de Fechamento: Zíper, Enchimento Fibra Siliconada: Poliéster. Qualidade camicado ou superior.',
    'Almofada em tricot 30 x 30, Gramatura: 100grs/m², Tipo de Fechamento: Zíper, Enchimento Fibra Siliconada: Poliéster. Qualidade camicado ou superior.',
    'UN',
    '6',
    'R$ 124,98',
    'R$ 749,88',
    '600794',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Jogo de lençol de cama 300 fios em algodão, cor branca, padrão queen, Composto por 04 peças, sendo 01 lençol inferior com elástico para colchões com até 40cm de altura, 01 lençol superior e 02 fronhas. Medidas: Sendo 01 lençol inferior com elástico para colchões com 140x190 cm a 158x198 cm e até 35cm de altura, 01 lençol superior entre 220x250 cm 235x260 cm e 02 Fronhas 70cm x 50cm; Qualidade mmartan ou superior.',
    'Jogo de lençol de cama 300 fios em algodão, cor branca, padrão queen, Composto por 04 peças, sendo 01 lençol inferior com elástico para colchões com até 40cm de altura, 01 lençol superior e 02 fronhas. Medidas: Sendo 01 lençol inferior com elástico para colchões com 140x190 cm a 158x198 cm e até 35cm de altura, 01 lençol superior entre 220x250 cm 235x260 cm e 02 Fronhas 70cm x 50cm; Qualidade mmartan ou superior.',
    'UN',
    '2',
    'R$ 802,76',
    'R$ 1.605,52',
    '612169',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Kit colcha 300 fios, cor branca, padrão queen, Composto por 05 peças, sendo 01 cobre-leito dupla face, 02 porta-travesseiros e 02 almofadas. 1 Colcha 240cm de comprimento e de 260cm a 275cm de largura e 2 Porta travesseiro 50 x 70 cm. Qualidade mmartan ou superior',
    'Kit colcha 300 fios, cor branca, padrão queen, Composto por 05 peças, sendo 01 cobre-leito dupla face, 02 porta-travesseiros e 02 almofadas. 1 Colcha 240cm de comprimento e de 260cm a 275cm de largura e 2 Porta travesseiro 50 x 70 cm. Qualidade mmartan ou superior',
    'UN',
    '2',
    'R$ 1.065,82',
    'R$ 2.131,64',
    '612181',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Saia de cama box, cor branca, padrão queen, malha impermeável. Qualidade mmartan ou superior.',
    'Saia de cama box, cor branca, padrão queen, malha impermeável. Qualidade mmartan ou superior.',
    'UN',
    '2',
    'R$ 235,89',
    'R$ 471,78',
    '445543',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Peseira em tricô, tear 100% algodão. Qualidade mmartan ou superior',
    'Peseira em tricô, tear 100% algodão. Qualidade mmartan ou superior',
    'UN',
    '3',
    'R$ 302,26',
    'R$ 906,78',
    '469171',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Jogo de lençol de cama 300 fios em algodão, cor branca, padrão casal, Composto por 04 peças, sendo 01 lençol inferior com elástico para colchões com até 40cm de altura, 01 lençol superior e 02 fronhas. Qualidade mmartan ou superior',
    'Jogo de lençol de cama 300 fios em algodão, cor branca, padrão casal, Composto por 04 peças, sendo 01 lençol inferior com elástico para colchões com até 40cm de altura, 01 lençol superior e 02 fronhas. Qualidade mmartan ou superior',
    'UN',
    '1',
    'R$ 1.019,50',
    'R$ 1.019,50',
    '445386',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Kit colcha 300 fios, cor branca, padrão casal, Composto por 05 peças, sendo 01 cobre-leito dupla face, 02 porta-travesseiros e 02 almofadas. Qualidade mmartan ou superior',
    'Kit colcha 300 fios, cor branca, padrão casal, Composto por 05 peças, sendo 01 cobre-leito dupla face, 02 porta-travesseiros e 02 almofadas. Qualidade mmartan ou superior',
    'UN',
    '1',
    'R$ 1.374,48',
    'R$ 1.374,48',
    '612176',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
;