-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('FUNDAÇÃO HEMOCENTRO DE BRASÍLIA', 'FHB', '86.743.457/0001-01')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('FRESENIUS HEMOCARE BRASIL LTDA.', '49.601.107/0001-84')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '022/2023',
        'Contrato',
        '00063-00004260/2023-51',
        NULL,
        'Contrato',
        '022/2023',
        's3://compras-ia-np/Contratos/00394684000153-000015-2023.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '86.743.457/0001-01' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '49.601.107/0001-84' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '022/2023'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000015-2023.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '022/2023'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000015-2023.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'BOLSA PARA ARMAZENAMENTO DE CONCENTRADO DE PLAQUETAS COM FILTRO ACOPLADO PARA FILTRAÇÃO DE CONCENTRADO DE PLAQUETAS',
    '',
    'Unidade',
    '3.280',
    'R$83,79',
    'R$274.831,20',
    '422498',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'BOLSA TRIPLA PARA COLETA DE SANGUE CPD/SAG-M (PLAQUETAS 5 DIAS)',
    '',
    'Unidade',
    '5.516',
    'R$45,53',
    'R$251.143,48',
    '373487',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'BOLSA QUÁDRUPLA CPD/SAG-M TOP AND BOTTOM (TAB) COM FILTRO ACOPLADO PARA FILTRAÇÃO DE CONCENTRADO DE HEMÁCIAS',
    '',
    'Unidade',
    '22.008',
    'R$93,56',
    'R$2.059.068,48',
    '370519',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'HOMOGENEIZADOR AUTOMÁTICO DE BOLSAS DE SANGUE',
    '',
    'Unidade',
    '22',
    'R$17.023,38',
    'R$102.140,28',
    '451521',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
;