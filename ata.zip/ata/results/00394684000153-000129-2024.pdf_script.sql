-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('DISTRITO FEDERAL', 'VGDF', '07.187.000/0001-91')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('39.805.124 RAFAEL LIMA DINIZ', '39.805.124/0001-80')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '35/2024',
        'Contrato',
        '04043-00001124/2024-42',
        TO_DATE('22/05/2023', 'DD/MM/YYYY'),
        'Contrato',
        '35/2024',
        's3://compras-ia-np/Contratos/00394684000153-000129-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '07.187.000/0001-91' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '39.805.124/0001-80' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '35/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000129-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '35/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000129-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Airfryer',
    'com no mínimo as seguintes especificações: cesto que comporte no mínimo 5.5 litros; controle de temperatura a partir de 200ºC; potência mínima de 1750W; voltagem 220w.',
    'Unidade',
    '02',
    'R$ 498,90',
    'R$ 997,80',
    '601738',
    'Material',
    'LAGO SUL/DF'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Purificador de água',
    'com no mínimo as seguintes especificações: redução de cloro livre; armazenamento de água gelada de no mínimo 2,0 (dois) litros; capacidade de gelar no mínimo 3 (três) litros por hora; voltagem 220W; potência mínima de 1400W.',
    'Unidade',
    '04',
    'R$ 1.799,00',
    'R$ 7.196,00',
    '405311',
    'Material',
    'LAGO SUL/DF'
FROM contrato_id
;