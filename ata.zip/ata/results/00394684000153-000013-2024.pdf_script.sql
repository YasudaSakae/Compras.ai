-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('GABINETE DA VICE-GOVERNADORA DO DISTRITO FEDERAL', 'VGDF', '07.187.000/0001-91')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('ATLAS ENGENHARIA E PROJETOS LTDA', '51.097.157/0001-18')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '2/2024',
        'Contrato de Aquisição de Bens',
        '04043-00001630/2023-51',
        NULL,
        'Contrato',
        '2/2024',
        's3://compras-ia-np/Contratos/00394684000153-000013-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '07.187.000/0001-91' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '51.097.157/0001-18' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '2/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000013-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '2/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000013-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Ar-Condicionado Portátil',
    'Capacidade mínima (BTU/h): 9.000 BTU/h, Gás Refrigerante: R-410A, Ciclo: Frio, Voltagem: 220v, nível De Ruído máximo: 55dba, dimensões mínimas (p X L X H):36,5 X 36,5cm X 86,0 Cm peso Bruto(kg): 30 Kg, garantia: 1 Ano (ofertada Pelo Fornecedor).',
    'Unidade',
    '2',
    'R$ 3.400,00',
    'R$ 6.800,00',
    '602756',
    'Material',
    'LAGOSUL/DF'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Ar-Condicionado',
    'Descrição: capacidade de refrigeração 9.000Btu/h; modelo SPLIT INVERTER, Tensão: 220V. Frequência: 60 Hz, com a maior eficiência energética da categoria. Garantia: Mínima 12 (doze) meses(do fabricante); fornecimento e instalação.',
    'Unidade',
    '7',
    'R$ 2.666,00',
    'R$ 18.662,00',
    '2020',
    'Material',
    'LAGOSUL/DF'
FROM contrato_id
;