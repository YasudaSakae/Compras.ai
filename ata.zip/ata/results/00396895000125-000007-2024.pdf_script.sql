-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('LABORATÓRIO FEDERAL DE DEFESA AGROPECUÁRIA – LFDA/RS', 'LFDA/RS', '00.396.895/0045-46')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('LABWARE BRASIL SERVIÇOS DE INFORMATICA LTDA.', '13.011.238/0001-64')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '01/2024',
        'Contrato',
        '21043.000537/2023-48',
        NULL,
        'Contrato',
        '01/2024',
        's3://compras-ia-np/Contratos/00396895000125-000007-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0045-46' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '13.011.238/0001-64' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '01/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000007-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '01/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000007-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Horas técnicas para utilização em ações de manutenções evolutivas do sistema LIMS Labware em utilização na Rede LFDA',
    '',
    'hora',
    '25.000',
    'R$ 277,69',
    'R$ 6.942.250,00',
    '26972',
    'Serviço',
    'Porto Alegre (RS), São José (SC)'
FROM contrato_id
;