-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('Secretaria de Estado de Justiça e Cidadania do Distrito Federal', 'SEJUS', '08.685.528/0001-53')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('CONEXAO 5 DISTRIBUIDORA E SERVICOS LTDA', '96.317.508/0001-97')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '32/2023-SEJUS',
        'Contrato',
        '00400-00069180/2022-82',
        NULL,
        'Contrato',
        '32/2023-SEJUS',
        's3://compras-ia-np/Contratos/00394684000153-000030-2023.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '08.685.528/0001-53' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '96.317.508/0001-97' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '32/2023-SEJUS'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000030-2023.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '32/2023-SEJUS'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000030-2023.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Bandeja Para Medicação',
    'Bandeja, material aço inoxidável, tipo lisa, dimensões cerca de 30 x 20 x 4 cm, esterilidade esterilizável. Fabricante / Marca: FORTINO X',
    'UND',
    '6',
    'R$ 86,95',
    'R$ 521,70',
    '440141',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Cuba Redonda',
    'Cuba Uso Hospitalar Material: Aço Inox , Formato: Redondo, Capacidade: Cerca De 300 a 500 ML. Fabricante / Marca: FORTINO X',
    'UND',
    '5',
    'R$ 21,75',
    'R$ 108,75',
    '439209',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Cuba Rim',
    'Cuba uso hospitalar material: aço inox , capacidade: cerca de 700 ml, formato: tipo rim. Fabricante / Marca: FORTINO X',
    'UND',
    '4',
    'R$ 55,27',
    'R$ 221,08',
    '439214',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Coletor De Urina Masculino',
    'Coletor de urina masculino utilizada para coletar urina em pacientes do sexo masculino, pessoas com dificuldade de locomoção ou acamadas, ou em casos de incontinência urinária. fabricada em aço inoxidável, possuir alça, com capacidade de 1,0 litro, dimensões aproximadas 26x13cm. autoclavável. Fabricante / Marca: FORTINO X',
    'UND',
    '5',
    'R$ 119,00',
    'R$ 595,00',
    '385777',
    'Material',
    'Brasília (DF)'
FROM contrato_id
;