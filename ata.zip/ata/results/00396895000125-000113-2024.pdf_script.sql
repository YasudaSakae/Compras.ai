-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('Superintendência de Agricultura e Pecuária em Minas Gerais', 'SFA-MG/MAPA', '00.396.895/0026-83')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('CXW SERVICOS E NEGOCIOS DE TECNOLOGIA LTD', '07.342.935/0001-03')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '02/2024',
        'Contrato Administrativo',
        '21028.007346/2023-03',
        TO_DATE('04/04/2024', 'DD/MM/YYYY'),
        'Contrato',
        '02/2024',
        's3://compras-ia-np/Contratos/00396895000125-000113-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0026-83' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '07.342.935/0001-03' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '02/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000113-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '02/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000113-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'IMPRESSÃO MONOCROMÁTICO',
    '',
    'cópias/mês/equipamento',
    '16564',
    'R$ 0,086',
    'R$ 17.094,05',
    '26816',
    'Serviço',
    'Belo Horizonte (MG)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'IMPRESSÃO POLICROMÁTICO',
    '',
    'cópias/mês/equipamento',
    '1607',
    'R$ 0,46',
    'R$ 8.870,64',
    '26859',
    'Serviço',
    'Belo Horizonte (MG)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'LOCAÇÃO DE EQUIPAMENTO MONOCROMATICO',
    '',
    'Equipamentos',
    '35',
    'R$ 164,28',
    'R$ 68.997,60',
    '26735',
    'Serviço',
    'Belo Horizonte (MG)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'LOCAÇÃO DE EQUIPAMENTO POLICROMATICO',
    '',
    'Equipamentos',
    '12',
    'R$ 225',
    'R$ 32.400,00',
    '26760',
    'Serviço',
    'Belo Horizonte (MG)'
FROM contrato_id
;