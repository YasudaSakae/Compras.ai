-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('FUNDAÇÃO HEMOCENTRO DE BRASÍLIA', 'FHB', '86.743.457/0001-01')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('TARGET ENGENHARIA E CONSULTORIA LTDA.', '00.000.028/0001-29')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '034/2023',
        'Contrato',
        '00063-00000038/2023-89',
        TO_DATE('14/11/2023', 'DD/MM/YYYY'),
        'Contrato',
        '034/2023',
        's3://compras-ia-np/Contratos/00394684000153-000064-2023.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '86.743.457/0001-01' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '00.000.028/0001-29' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '034/2023'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000064-2023.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '034/2023'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000064-2023.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Assinatura de base de dados com coletânea digital das Normas Técnicas Brasileiras (NBR) da Associação Brasileira de Normas Técnicas (ABNT) e da International Organization for Standardization (ISO)',
    '1. ABNT NBR ISO 9000 : Sistemas de gestão da qualidade – Fundamentos e vocabulário; 2. ABNT NBR ISO 9001 : Sistemas de gestão da qualidade – Requisitos; 3. ABNT NBR ISO/IEC 17021-1 : Avaliação da conformidade – Requisitos para organismos que fornecem auditoria e certificação de sistemas de gestão – Parte 1: Requisitos; 4. ABNT NBR ISO/IEC 17025 : Requisitos gerais para a competência de laboratórios de ensaio e calibração; 5. ABNT NBR ISO 19011 : Diretrizes para auditoria de sistemas de gestão; 6. ABNT NBR ISO 31000 : Gestão de riscos – Diretrizes; 7. ABNT NBR IEC 31010 : Gestão de riscos — Técnicas para o processo de avaliação de riscos; 8. ABNT NBR ISO 10002 : Gestão da qualidade – Satisfação do cliente – Diretrizes para o tratamento de reclamações nas organizações; 9. ABNT NBR ISO 10015 : Gestão da qualidade – Diretrizes para gestão da competência e desenvolvimento de pessoas; 10. ABNT NBR ISO/IEC 17050-1 : Avaliação da conformidade – Declaração de conformidade de fornecedor – Parte 1: Requisitos gerais; 11. ABNT NBR ISO 37000: Governança de organizações – Orientações; 12. ABNT NBR 12962: Extintores de incêndio – Inspeção e manutenção; 13. ABNT NBR 12779: Mangueira de incêndio – Inspeção, manutenção e cuidados; 14. ABNT NBR 10898: Sistema de iluminação de emergência; 15. ABNT NBR 9077 : Saídas de emergência em edifícios; 16. ABNT NBR 14276: Brigada de incêndio e emergência – Requisitos e procedimentos; 17. ABNT NBR 5419-1: Proteção contra descargas atmosféricas – Parte 1: Princípios Gerais; 18. ABNT NBR 5410 : Instalações elétricas de baixa tensão; 19. ABNT NBR ISO/CIE 8995-1: Iluminação de ambientes de trabalho – Parte 1: Interior 20. ABNT NBR 16537: Acessibilidade – Sinalização tátil no piso – Diretrizes para elaboração de projetos e instalação; 21. ABNT NBR 9050 : Acessibilidade a edificações, mobiliário, espaços e equipamentos urbanos; 22. ABNT NBR 14565: Cabeamento estruturado para edifícios comerciais; 23. ABNT NBR 11802: Pisos elevados – Especificação; 24. ABNT NBR 5674: Manutenção de edificações – Requisitos para o sistema de gestão de manutenção; 25. ABNT NBR 16747: Inspeção predial – Diretrizes, conceitos, terminologia e procedimento; 26. ABNT NBR 5462: Confiabilidade e mantenabilidade; 27. ABNT NBR 15943: Diretrizes para um programa de gerenciamento de equipamentos de infraestrutura de serviços de saúde e de equipamentos para a saúde; 28. ABNT NBR ISO 21500: Gerenciamento de projeto, programa e portfólio — Contexto e conceitos; 29. ABNT NBR ISO 10006: Sistemas de gestão da qualidade - Diretrizes para a gestão da qualidade em empreendimentos; 30. ABNT NBR ISO 1135-4 : Equipamentos de transfusão para uso médico – Parte 4: Equipos de transfusão para uso único; 31. ABNT NBR ISO 8536 -5: Equipamento de infusão para uso médico – Parte 5: Equipos de infusão com bureta para uso único, alimentação por gravidade.',
    'Assinatura',
    '1',
    'R$1.680,00',
    'R$1.680,00',
    '23108',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
;