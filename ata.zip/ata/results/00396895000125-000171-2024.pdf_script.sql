-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('MINISTÉRIO DA AGRICULTURA E PECUÁRIA', 'MAPA', '00.396.895/0011-05')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('ORA CLE DO BRASIL SISTEMAS LTDA', '59.456.277/0003-38')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '3/2024',
        'Contrato Administrativo',
        '21000.054608/2023-29',
        NULL,
        'Contrato',
        '3/2024',
        's3://compras-ia-np/Contratos/00396895000125-000171-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0011-05' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '59.456.277/0003-38' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '3/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000171-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '3/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000171-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Atualização e suporte a software - Web Logic Suite',
    '',
    'Core',
    '26',
    'R$ 44.269,97',
    'R$ 1.151.019,22',
    '27464',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Atualização e suporte a software - DataBase Diagnostic Pack',
    '',
    'Core',
    '32',
    'R$ 8.065,99',
    'R$ 258.111,68',
    '27464',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Atualização e suporte a software - DataBase Eenterprise Edition',
    '',
    'Core',
    '32',
    'R$ 53.405,87',
    'R$ 1.708.987,84',
    '27464',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Atualização e suporte a software - DataBase Partitioning',
    '',
    'Core',
    '32',
    'R$ 12.105,00',
    'R$ 387.360,00',
    '27464',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Atualização e suporte a software - Database RAC (Real Application Cluster)',
    '',
    'Core',
    '32',
    'R$ 24.736,16',
    'R$ 791.557,12',
    '27464',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Atualização e suporte a software - DataBase Tunning Pack',
    '',
    'Core',
    '32',
    'R$ 5.375,29',
    'R$ 172.009,28',
    '27464',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Atualização e suporte a software - Servidor gerenciador de armazenamento (storage',
    '',
    'CPU',
    '56',
    'R$ 9.939,64',
    'R$ 556.619,84',
    '27464',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Atualização e suporte a software - Máquina Exadata X5-2',
    '',
    'Equipamento',
    '01',
    'R$ 436.220,34',
    'R$ 436.220,34',
    '27090',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
;