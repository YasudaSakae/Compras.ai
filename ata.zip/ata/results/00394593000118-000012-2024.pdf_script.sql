-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('Instituto de Assistência Técnica e Extensão Rural de Roraima - IATER/RR', 'IATER/RR', '45.386.905/0001-80')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('EVATUS DESENVOLVIMENTO ORGANIZACIONAL LTDA', '51.288.329/0001-30')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '006/2024',
        'Contrato',
        '18303.000938/2024.66',
        TO_DATE('21/03/2024', 'DD/MM/YYYY'),
        'Contrato',
        '006/2024',
        's3://compras-ia-np/Contratos/00394593000118-000012-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '45.386.905/0001-80' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '51.288.329/0001-30' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '006/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394593000118-000012-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '006/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394593000118-000012-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Pagamento de taxa de Inscrição em Curso Prático em Operação do Compras.gov conforme a Nova Lei de Licitações - Lei nº 14.133/21',
    'Curso Prático em Operação do Compras.gov conforme a Nova Lei de Licitações - Lei nº 14.133/21',
    'Und.',
    '05',
    'R$ 2.990,00',
    'R$ 14.950,00',
    '25232',
    'Serviço',
    'Boa Vista (RR)'
FROM contrato_id
;