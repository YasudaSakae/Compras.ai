-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('FUNDAÇÃO HEMOCENTRO DE BRASÍLIA', 'FHB', '86.743.457/0001-01')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('GS REFORMA E LIMPEZA DE ESTOFADOS EM GERAL LTDA', '34.292.339/0001-20')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '027/2023',
        'Contrato',
        '00063-00004677/2023-13',
        NULL,
        'Contrato',
        '027/2023',
        's3://compras-ia-np/Contratos/00394684000153-000032-2023.pdf',
        'Parcial',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '86.743.457/0001-01' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '34.292.339/0001-20' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '027/2023'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000032-2023.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '027/2023'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000032-2023.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Recuperação/restauração de poltrona fixa de auditório, estilo longarinas, com assento retrátil: estrutura em madeira maciça, encosto e assento estofado sobre chapa de compensado, articulação do assento e fixação de encostos em chapa estampada de aço pintadas na cor preto fosco. Auditório composto por 112 poltronas em tecido, com estrutura em madeira, fixas no piso acarpetado por meio de parafusos e buchas de fixação, divididas em 14 fileiras, com 8 poltronas unidas entre si por fileira.',
    'Recuperação/restauração de poltrona fixa de auditório, estilo longarinas, com assento retrátil: estrutura em madeira maciça, encosto e assento estofado sobre chapa de compensado, articulação do assento e fixação de encostos em chapa estampada de aço pintadas na cor preto fosco. Auditório composto por 112 poltronas em tecido, com estrutura em madeira, fixas no piso acarpetado por meio de parafusos e buchas de fixação, divididas em 14 fileiras, com 8 poltronas unidas entre si por fileira.',
    'Serviço',
    '1',
    'R$38.400,00',
    'R$38.400,00',
    '5410',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
;