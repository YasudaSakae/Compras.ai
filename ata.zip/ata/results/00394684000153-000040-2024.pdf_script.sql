-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('DISTRITO FEDERAL', 'VGDF', '07.187.000/0001-91')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('39.805.124 RAFAEL LIMA DINIZ', '39.805.124/0001-80')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '15/2024',
        'Contrato',
        '04043-00000297/2024-43',
        TO_DATE('23/04/2024', 'DD/MM/YYYY'),
        'Contrato',
        '15/2024',
        's3://compras-ia-np/Contratos/00394684000153-000040-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '07.187.000/0001-91' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '39.805.124/0001-80' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '15/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000040-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '15/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000040-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Conjunto 3 peças para banheiro em vidro',
    'Composto por: 01 porta-sabonete líquido, 01 saboneteira e 01 porta-escova',
    'UN',
    '3',
    'R$ 201,96',
    'R$ 605,88',
    '231376',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Bandeja Metal prata com espelho e vidro',
    'Medidas: 30x20x4cm',
    'UN',
    '3',
    'R$ 145,53',
    'R$ 436,59',
    '482850',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Toalheiro de pia duplo quadrado em inox',
    '',
    'UN',
    '3',
    'R$ 246,51',
    'R$ 739,53',
    '404212',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Difusor de ambientes com varetas – 250ml – Jasmin Branco',
    '',
    'UN',
    '3',
    'R$ 165,33',
    'R$ 495,99',
    '608303',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Ducha higiênica com derivação Loren Lo C82 cromado',
    '',
    'UN',
    '5',
    'R$ 368,50',
    'R$ 1.842,50',
    '335014',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Chuveiro elétrico Acqua Storm Ultra branco cromado 7800w 220v',
    '',
    'UN',
    '4',
    'R$ 495,99',
    'R$ 1.983,96',
    '250450',
    'Material',
    'Lago Sul (DF)'
FROM contrato_id
;