-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('DISTRITO FEDERAL, POR INTERMÉDIO DA VICE-GOVERNADORIA DO DISTRITO FEDERAL', 'VGDF', '07.187.000/0001-91')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('53.111.194 MATHEUS LETTIERY SILVA NASCIMENTO', '53.111.194/0001-69')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '24/2024',
        'Contrato',
        '04043-00001698/2023-30',
        NULL,
        'Contrato',
        '24/2024',
        's3://compras-ia-np/Contratos/00394684000153-000085-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '07.187.000/0001-91' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '53.111.194/0001-69' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '24/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000085-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '24/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000085-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Estabilizador de para celular 3 eixos',
    'Tipo mão , Comunicação: Bluetooth; Conﬁgurado para câmeras de ação; Conﬁgurado para Smartphones; Titulação ângulo 270 graus, Ângulo de rolamento de180 graus, Ângulo panorâmico 320 graus; Tamanho 291x120x50mm',
    'UNID',
    '01',
    'R$ 745,00',
    'R$ 745,00',
    '485492',
    'Material',
    'LAGO SUL/DF'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Iluminador LED 18 Polegadas, 46CM, RingLight 45 W, C/Tripe 1,80 m + 3 suporte tipo de lâmpada LED',
    'Potência 12v/5a, Ajuste de Brilho , Iluminação geral 6000Lúmens, Modo de cor: 2/3200k, 580oc(6 luzes amarelas)',
    'UNID',
    '02',
    'R$ 225,00',
    'R$ 450,00',
    '600317',
    'Material',
    'LAGO SUL/DF'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Kit Youtuber 2 Softbox 50 X 70 E27 Luz + 2Tripés 2 m',
    '',
    'UNID',
    '01',
    'R$ 475,00',
    'R$ 475,00',
    '452766',
    'Material',
    'LAGO SUL/DF'
FROM contrato_id
UNION ALL
SELECT

    id,
    'HD Externo 4tb',
    '',
    'UNID',
    '02',
    'R$ 800,00',
    'R$ 1.600,00',
    '611530',
    'Material',
    'LAGO SUL/DF'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Radio Flash C/2 Receptores Para DslrCanon Nikon 16 Canais',
    'Frequencia433MHz',
    'UNID',
    '01',
    'R$ 350,00',
    'R$ 350,00',
    '407103',
    'Material',
    'LAGO SUL/DF'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Microfone Lapela Sem Fio – Anrruído',
    'Transmissão Sem Fio 200 Metros, 8 Horas de Duração da Bateria, Microfone Duplo',
    'UNID',
    '01',
    'R$ 910,00',
    'R$ 910,00',
    '610412',
    'Material',
    'LAGO SUL/DF'
FROM contrato_id
;