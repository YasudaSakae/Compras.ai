-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('LABORATÓRIO DE DEFESA AGROPECUÁRIA - LFDA/RS', 'LFDA/RS', '00.396.895/0045-46')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('MARCOS ANDRE REICHERT & CIA LTDA', '06.941.912/0001-44')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '9/2024',
        'Contrato Administrativo',
        '21043.000106/2023-81',
        TO_DATE('25/06/2024', 'DD/MM/YYYY'),
        'Contrato',
        '9/2024',
        's3://compras-ia-np/Contratos/00396895000125-000197-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0045-46' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '06.941.912/0001-44' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '9/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000197-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '9/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000197-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Serviço Preventivo e Corretivo de Desratização',
    'Unidade Física Ponta Grossa - UFPG - Área Interna 7.000 m². Aplicações Mensais conforme Cronograma.',
    'm2',
    '420000',
    'R$ 0,12',
    'R$ 50.400,00',
    '3417',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Serviço Preventivo e Corretivo de Desinsetização',
    'Unidade Física Ponta Grossa - UFPG - Área Interna 7.000 m² e Área Externa 6.000m². Aplicações Trimestrais conforme Cronograma.',
    'm2',
    '260000',
    'R$ 0,12',
    'R$ 31.200,00',
    '3417',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Serviço Preventivo e Corretivo de Descupinização',
    'Unidade Física Ponta Grossa - UFPG - Área Interna 7.000 m². Aplicações Semestrais conforme Cronograma.',
    'm2',
    '70000',
    'R$ 0,12',
    'R$ 8.400,00',
    '3417',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
;