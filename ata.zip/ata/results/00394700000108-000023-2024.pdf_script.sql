-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('DISTRITO FEDERAL, por intermédio da SECRETARIA DE ESTADO DE SAÚDE', 'SES/DF', '00.394.700/0001-08')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('MEDIMPLANTES – SERVIÇOS E PRODUTOS ESPECIALIZADOS LTDA', '14.683.737/0002-41')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '052769/2024',
        'Contrato Administrativo',
        '00060-00328090/2023-81',
        NULL,
        'Contrato',
        '052769/2024',
        's3://compras-ia-np/Contratos/00394700000108-000023-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.394.700/0001-08' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '14.683.737/0002-41' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '052769/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394700000108-000023-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '052769/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394700000108-000023-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Contratação de serviços de manutenção preventiva e corretiva com reposição de peças nos VENTILADORES PULMONARES, modelo VG 70, marca Aeonmed, pertencentes ao patrimônio da Secretária de Estado de Saúde do Distrito Federal (SES/DF).',
    'Manutenção preventiva e corretiva com reposição de peças nos ventiladores pulmonares, modelo VG 70, marca Aeonmed',
    'UNIDADE',
    '82',
    'R$ 1.533,00',
    'R$ 1.508.472,00',
    '5428',
    'Serviço',
    'Brazlândia (DF), Ceilândia (DF), Samambaia (DF), Taguatinga (DF), Guará (DF), Planaltina (DF), Sobradinho (DF), Paranoá (DF), Asa Sul (DF), Asa Norte (DF)'
FROM contrato_id
;