-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('FUNDAÇÃO HEMOCENTRO DE BRASÍLIA', 'FHB', '86.743.457/0001-01')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('FRESENIUS HEMOCARE BRASIL LTDA.', '49.601.107/0001-84')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '001/2024',
        'Contrato Administrativo',
        '00063-00000065/2024-32',
        NULL,
        'Contrato',
        '001/2024',
        's3://compras-ia-np/Contratos/00394684000153-000015-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '86.743.457/0001-01' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '49.601.107/0001-84' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '001/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000015-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '001/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000015-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'BOLSA PARA ARMAZENAMENTO DE CONCENTRADO DE PLAQUETAS COM FILTRO ACOPLADO PARA FILTRAÇÃO DE CONCENTRADO DE PLAQUETAS',
    'Para uso no processo de obtenção de pool de plaquetas desleucotizado. Material: confeccionada em PVC atóxico, estéril e livre de agentes pirogênicos, com plastificante especial para conservação de plaquetas por pelo menos 5 dias. Formato: anatômico com todos os cantos internos arredondados. Tamanho/Capacidade: a partir de 1.000 mL. Características Adicionais: As bolsas deverão estar embaladas individualmente. A tubulação do sistema deve ser compatível para o uso em técnicas estéreis de conexão. Possuir filtro para remoção de leucócitos em concentrado de plaquetas acoplado ao sistema. O filtro deve suportar uma centrifugação de aproximadamente 2.000g. Após a centrifugação a contagem de leucócitos deve ser inferior a 5 x 106/ unidade. As instruções de uso e rotulagem deverão estar em português e de acordo com os REGULAMENTOS TÉCNICOS VIGENTES DO MINISTÉRIO DA SAÚDE. O rótulo deverá conter as informações de acordo com a Seção VIII da RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021. A bolsa deverá preservar o concentrado de plaquetas por pelo menos 5 (cinco) dias e manter o pH acima de 6,4 no último dia de armazenamento. O insumo deve atender a todos os requisitos da RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021, que dispõe sobre bolsas plásticas para coleta, armazenamento e transferência de sangue humano e seus componentes. Possuir registro na ANVISA.',
    'Unidade',
    '6.564',
    'R$104,80',
    'R$687.907,20',
    '422498',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'BOLSA TRIPLA PARA COLETA DE SANGUE CPD/SAG-M (PLAQUETAS 5 DIAS)',
    'Para uso no processo de obtenção de Concentrado de Hemácias, Plasma Fresco Congelado, Plaquetas de PRP, Plasma Isento de Crio e Crioprecipitado. Bolsa Principal: deve estar de acordo com o desenho esquemático disposto na norma ISO 3826-1, com anticoagulante CPD (citrato, fosfato, dextrose), confeccionada em PVC atóxico, estéril e apirogênica. Formato: anatômico com cantos internos arredondados, com orifícios na parte superior necessários para adaptação em equipamentos automatizados de processamento e de acordo com a RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021. Tamanho/Capacidade: 450 mL + ou - 45 mL de sangue, com coletor de amostra. Bolsas Satélites: capacidade de 450 mL + ou - 45 mL, resistente à centrifugação (5.000 g por 30 minutos), congelamento a baixa temperatura (-80°C) e descongelamento a 37°C; com orifícios na parte superior necessários para adaptação em equipamentos automatizados de processamento, sendo que uma das bolsas satélite é confeccionada com plástico PVC atóxico e plastificante Tri-2-exil-Trimelitato (TOTM) ou di-2-etil-hexilftalato (DEHP) especial para preservação de plaquetas por pelo menos 5 (cinco) dias e pH acima de 6,4 do concentrado de plaquetas no último dia de armazenamento; sendo que uma bolsa satélite contenha solução preservadora SAG-M (salina, adenina, glicose, manitol). O tubo de transferência que permanece nos hemocomponentes deve ser identificado numericamente com marcações idênticas em intervalos de aproximadamente 75 mm; Tubos de coleta, transferência e saída: devem atender todos os requisitos da RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021. Todos os tubos deverão ser compatíveis com equipamento de conexão estéril de tubos de PVC. Coletor de amostra: Sistema para coleta de amostras de sangue deve ser composto por uma mini-bolsa com capacidade em torno de 40 mL e adaptador para tubos a vácuo. Tal dispositivo deverá ser acoplado à bolsa na sua embalagem original, sem adaptadores separados a fim de facilitar o manuseio; deve também permitir a coleta das amostras antes da coleta do sangue na bolsa principal em sistema fechado, reduzindo a contaminação bacteriana do sangue coletado na bolsa. Características Adicionais: A Agulha para coleta deve atender à Seção IV da RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021. As instruções de uso e rotulagem deverão estar em português e de acordo com os REGULAMENTOS TÉCNICOS VIGENTES DO MINISTÉRIO DA SAÚDE. O rótulo deverá conter as informações de acordo com a Seção VIII da RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021. O insumo deve atender a todos os requisitos da RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021, que dispõe sobre bolsas plásticas para coleta, armazenamento e transferência de sangue humano e seus componentes. Possuir registro na ANVISA.',
    'Unidade',
    '11.167',
    'R$57,40',
    'R$640.985,80',
    '373487',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'BOLSA QUÁDRUPLA CPD/SAG-M TOP AND BOTTOM (TAB) COM FILTRO ACOPLADO PARA FILTRAÇÃO DE CONCENTRADO DE HEMÁCIAS',
    'Para uso no processo de obtenção de Concentrado de Hemácias Filtrado, Camada Leucoplaquetária – buffy-coat e Plasma Fresco Congelado. Bolsa Principal: deve estar de acordo com o desenho esquemático disposto na norma ISO 3826-1, com anticoagulante CPD (citrato, fosfato, dextrose), confeccionada em PVC atóxico e plastificante di-2-etil-hexilftalato (DEHP), estéril e apirogênica. Formato: anatômico com cantos internos arredondados, com orifícios na parte superior necessários para adaptação em equipamentos automatizados de processamento e de acordo com a RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021. Tamanho/Capacidade: 450 mL + ou - 45 mL de sangue, com coletor de amostra. Bolsas Satélites: capacidade de 450 mL + ou - 45 mL, resistente à centrifugação (5.000g por 30 minutos), congelamento a baixa temperatura (-80°C) e descongelamento a 37°C; com orifícios na parte superior necessários para adaptação em equipamentos automatizados de processamento, sendo que uma outra bolsa satélite deve conter solução preservadora de hemácias SAG-M (salina, adenina, glicose, manitol), através de um tubo de transferência provido de filtro acoplado (inline) para remoção de leucócitos de concentrado de hemácias, com tubo de transferência que permanece nos hemocomponentes identificado numericamente com marcações idênticas em intervalos de aproximadamente 75 mm; Tubos de coleta, transferência e saída: devem atender todos os requisitos da RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021. Todos os tubos deverão ser compatíveis com equipamento de conexão estéril de tubos de PVC. O filtro para remoção de leucócitos: deverá ser integralmente ligado ao conjunto. Após filtração, a contagem de leucócitos residuais do Concentrado de Hemácias deve ser menor que 5 x 106/ unidade, conforme Portaria de Consolidação MS -GM nº 5, de 28/09/2017 e RDC-ANVISA Nº 34 de 11 de junho de 2014. Coletor de amostra: Sistema para coleta de amostras de sangue deve ser composto por uma mini-bolsa com capacidade em torno de 40 mL e adaptador para tubos a vácuo. Tal dispositivo deverá ser acoplado à bolsa na sua embalagem original, sem adaptadores separados a fim de facilitar o manuseio; deve também permitir a coleta das amostras antes da coleta do sangue na bolsa principal em sistema fechado, reduzindo a contaminação bacteriana do sangue coletado na bolsa. Características Adicionais: A Agulha para Coleta deve atender à Seção IV da RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021. As instruções de uso e rotulagem deverão estar em português e de acordo com os REGULAMENTOS TÉCNICOS VIGENTES DO MINISTÉRIO DA SAÚDE. O rótulo deverá conter as informações de acordo com a Seção VIII da RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021. O insumo deve atender a todos os requisitos da RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021, que dispõe sobre bolsas plásticas para coleta, armazenamento e transferência de sangue humano e seus componentes. Possuir registro na ANVISA.',
    'Unidade',
    '43.883',
    'R$107,90',
    'R$4.734.975,70',
    '370519',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'BOLSA TRIPLA PARA COLETA DE SANGUE CPDA-1 - sem SAG Manitol (PLAQUETAS 5 DIAS)',
    'Para uso no processo de obtenção de Concentrado de Hemácias destinado a pacientes com indicação específica, Plasma Fresco Congelado, Plaquetas de PRP, Plasma Isento de Crio e Crioprecipitado. Bolsa Principal: deve estar de acordo com o desenho esquemático disposto na norma ISO 3826-1, com anticoagulante CPDA-1 (adenina, glicose, fosfato e citrato), confeccionada em PVC atóxico, estéril e apirogênica. Formato: anatômico com cantos internos arredondados, com orifícios na parte superior necessários para adaptação em equipamentos automatizados de processamento e de acordo com a RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021. Tamanho/Capacidade: 450 mL + ou - 45 mL de sangue, com coletor de amostra. Bolsas Satélites: capacidade de 450 mL + ou - 45 mL, resistente à centrifugação (5.000 g por 30 minutos), congelamento a baixa temperatura (-80°C) e descongelamento a 37°C; com orifícios na parte superior necessários para adaptação em equipamentos automatizados de processamento, sendo que uma das bolsas satélite é confeccionada com plástico PVC atóxico e plastificante Tri-2-exil-Trimelitato (TOTM) ou di-2-etil-hexilftalato (DEHP) especial para preservação de plaquetas por pelo menos 5 (cinco) dias e pH acima de 6,4 do concentrado de plaquetas no último dia de armazenamento. O tubo de transferência que permanece nos hemocomponentes deve ser identificado numericamente com marcações idênticas em intervalos de aproximadamente 75 mm; Tubos de coleta, transferência e saída: devem atender todos os requisitos da RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021. Todos os tubos deverão ser compatíveis com equipamento de conexão estéril de tubos de PVC. Coletor de amostra: Sistema para coleta de amostras de sangue deve ser composto por uma mini-bolsa com capacidade em torno de 40 mL e adaptador para tubos a vácuo. Tal dispositivo deverá ser acoplado à bolsa na sua embalagem original, sem adaptadores separados a fim de facilitar o manuseio; deve também permitir a coleta das amostras antes da coleta do sangue na bolsa principal em sistema fechado, reduzindo a contaminação bacteriana do sangue coletado na bolsa. Características Adicionais: A agulha para coleta deve atender à Seção IV da RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021. As instruções de uso e rotulagem deverão estar em português e de acordo com os REGULAMENTOS TÉCNICOS VIGENTES DO MINISTÉRIO DA SAÚDE. O rótulo deverá conter as informações de acordo com a Seção VIII da RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021. O insumo deve atender a todos os requisitos da RESOLUÇÃO DA DIRETORIA COLEGIADA - RDC N° 544, de 30 de agosto de 2021, que dispõe sobre bolsas plásticas para coleta, armazenamento e transferência de sangue humano e seus componentes. Possuir registro na ANVISA.',
    'Unidade',
    '288',
    'R$53,25',
    'R$15.336,00',
    '370570',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'EXTRATORA AUTOMÁTICO',
    'O equipamento deve possuir sistema automático para obtenção de hemocomponentes, garantindo a reprodutibilidade do processo; qualidade na remoção do buffy-coat e na separação dos hemocomponentes. Para uso na Gerência de Processamento – GPRO/DPDH/UNITEC/FHB. Forma de Apresentação - Especificações: Possuir sistema de selagem automática de tubos de PVC incorporado ao conjunto, que possibilite fazer duas selagens na bolsa de plasma, de forma a atender ao solicitado na RDC-ANVISA Nº 34 de 11 de junho de 2014. Art. 5: “O tubo coletor da bolsa de plasma deve ter uma extensão mínima de 15 cm com duas soldaduras, uma proximal e outra distal. Parágrafo único: o tubo a que se refere este deve ficar fixado nas bolsas”; Cada extrator deverá possuir no mínimo 02 (duas) balanças integradas, para registro automático do peso dos hemocomponentes; Cada extrator deverá possuir 1 (um) leitor óptico de código de barras para leitura de etiquetas de diversos tipos de códigos de barras, CODABAR, CODE 128, CODE 39, entre outros; Possuir capacidade de interligação em rede, com o sistema de gerenciamento e informação do ciclo do sangue da Fundação Hemocentro de Brasília – SistHemo-DF ou sistema similar, permitindo a garantia da rastreabilidade do processo; Cada extrator deverá se comunicar através de rede, possibilitando que os resultados gerados sejam gravados em arquivo de texto (.txt) no layout já existente na FHB; Possuir capacidade de troca de informações por arquivos textos (.txt) no layout já existente e conforme processo de trabalho já definidos na FHB, a fim de executar tarefas pré-programadas visando à obtenção dos valores necessários à extração dos hemocomponentes; Os equipamentos podem possuir dispositivos automáticos para quebra de lacre. Caso o equipamento quebre automaticamente o lacre, as bolsas devem ser compatíveis. Deverá processar todas as bolsas solicitadas neste edital. Os extratores automatizados deverão informar pelo menos os seguintes dados: número da doação, operador 01 e 02 (início e fim do fracionamento), identificação das centrífugas, pesos das bolsas por balança, horário de início e término do fracionamento, status do processo (normal, abortar e repetir), tipo de bolsa e o programa utilizado. O sistema de automação deverá possibilitar programação para obtenção de parâmetros de hemocomponentes de acordo com as necessidades da Fundação Hemocentro de Brasília e com os exigidos nas legislações vigentes do Ministério da Saúde e ANVISA; Alimentação: Fonte automática 110-240 V AC – 50/60 Hz. Na falta de energia os extratores deverão permanecer em funcionamento por no mínimo 15 minutos, ininterruptamente em regime de trabalho. Os acessórios para gerenciamento e transmissão de dados, entre os extratores e o SistHemo-DF ou sistema similar, deverão ser fornecidos pela contratada, com a garantia de funcionamento ininterrupto por 15 minutos, na falta de energia.',
    'Unidade',
    '8',
    'R$34.739,00',
    'R$277.912,00',
    '8176',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'HOMOGENEIZADOR AUTOMÁTICO DE BOLSAS DE SANGUE',
    'O equipamento deve possuir sistema automático para obtenção de sangue total, garantindo a reprodutibilidade do processo de coleta. Para uso na Gerência de Coleta de Sangue de Doadores/DCD/UNITEC/PR/FHB Forma de Apresentação - Especificações: Possuir bandeja ampla e flexibilidade para utilização de diversos tipos de bolsas, incluindo bolsa com filtro acoplado; Possuir balança com tara automática e capacidade para até 1000g; Deve possuir programação do peso/volume de sangue a ser coletado, por meio de um sistema de balança digital. Possuir display digital, podendo ser acionado para redução do consumo de energia e utilizado com bateria; Possuir monitor com caracteres de fácil visibilidade e sistema de operação em língua portuguesa; Possuir indicadores de tempo de coleta, volume coletado (em mililitros) e peso (em gramas), hora, data, volume programado, nível de carga da bateria e indicador que o equipamento está conectado à rede elétrica; Possuir alarme visual e sonoro para final de coleta e fluxo baixo; Possuir "Clamp" corta fluxo automático com sistema de segurança para bloquear o fluxo de sangue quando é atingido o volume de sangue programado ou tempo máximo de coleta, não permitindo coleta de volume excedente; Deve impedir a retirada do tubo durante a coleta; Possuir leitor automático de código de barras; Deve realizar a leitura de diversos tipos de códigos de barras, CODABAR, CODE 128, CODE 39, entre outros; Possui sistema de comunicação de dados sem fio, permitindo sua utilização em coletas de sangue em unidades móveis; Possuir solução de gerenciamento dos dados, que forneça informações por meio de arquivo de texto (.txt), em ambiente de rede, para sistema de informatização de acordo com o layout já existente na FHB, através de código de barras; Possuir maleta para transporte, transformável em bancada para suporte do equipamento; Deve acompanhar uma bateria recarregável; Sistema de proteção contra efeito memória da bateria; Deve acompanhar uma seladora, para cada homogeneizador; Deve ser equipado com dispositivo com as seguintes características: painel na sua extremidade com os comandos básicos (início, pausa e fim de coleta), display que indica fluxo baixo; Possuir suporte para leitor de código de barras; Alimentação: Fonte automática 110-240 V AC – 50/60 Hz ou compatível com a rede local. Na falta de energia os homogeneizadores deverão permanecer em funcionamento por no mínimo 15 minutos, ininterruptamente em regime de trabalho. Deve acompanhar os equipamentos 6 placas resfriadoras de butanodiol para acondicionamento e resfriamento do sangue total coletado, dispostas em recipientes plásticos, vazados (abertos), de fácil limpeza e higienização. Devem resfriar as bolsas de sangue total acondicionadas na placa imediatamente após a coleta, para a faixa de temperatura entre 20 e 24ºC em até 3 horas, mantendo-as nesta faixa de temperatura por, no mínimo, mais 20 horas. Capacidade de resfriar no mínimo 8 (oito) bolsas de sangue total. Os acessórios para gerenciamento e transmissão de dados, entre os homogeneizadores e o SistHemo-DF, ou sistema similar, deverão ser fornecidos pela contratada, com a garantia de funcionamento ininterrupto por 15 minutos, na falta de energia.',
    'Unidade',
    '22',
    'R$20.399,50',
    'R$244.794,00',
    '451521',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
;