-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('FUNDAÇÃO HEMOCENTRO DE BRASÍLIA', 'FHB', '86.743.457/0001-01')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('MB ENGENHARIA E NEGÓCIOS LTDA.', '41.521.003/0001-58')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '031/2023',
        'Contrato',
        '00063-00005453/2023-29',
        TO_DATE('09/11/2023', 'DD/MM/YYYY'),
        'Contrato',
        '031/2023',
        's3://compras-ia-np/Contratos/00394684000153-000065-2023.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '86.743.457/0001-01' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '41.521.003/0001-58' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '031/2023'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000065-2023.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '031/2023'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000065-2023.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Contratação de serviço técnico especializado de engenharia e arquitetura para elaboração de projetos executivos de reforma do Piso Elevado (211,52m²)',
    'Serviço técnico especializado de elaboração de Estudos Técnicos Preliminares de Arquitetura.
Serviço técnico especializado de elaboração de Projeto Básico e Projeto Executivo de Arquitetura.
Serviço técnico especializado de elaboração de Projeto Básico e Projeto Executivo Complementar de Instalações Elétricas e Telefônicas Prediais.
Serviço técnico especializado de elaboração de Projeto Básico e Projeto Executivo de Instalações de Ventilação, Climatização e Exaustão Predial.
Serviço técnico especializado de elaboração de Projeto Básico e Projeto Executivo Complementar de Instalações de Segurança contra Incêndio e Pânico.
Serviço técnico especializado de elaboração de Projeto Básico e Projeto Executivo Complementar de Instalações de Cabeamento Estruturado, Automação e Lógica Predial.
Serviço Técnico Especializado de elaboração de Projeto Básico de Instalações Provisórias de Obra.
Serviço Técnico Especializado de elaboração de Cronograma de Obra.
Serviço Técnico Especializado de elaboração de Orçamento Sintético e Analítico de Obra.',
    'Serviço',
    '1',
    'R$14.947,50',
    'R$14.947,50',
    '20060',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
;