-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('SUPERINTENDÊNCIA FEDERAL DE AGRICULTURA E PECUÁRIA NO ESTADO DA PARAÍBA', 'SFA-PB', '00.396.895/0020-98')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('SUPREMA EMPREENDIMENTOS LTDA', '08.243.787/0001-24')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '1/2024',
        'Contrato Administrativo',
        '21032.001534/2023-51',
        TO_DATE('02/02/2024', 'DD/MM/YYYY'),
        'Contrato',
        '1/2024',
        's3://compras-ia-np/Contratos/00396895000125-000049-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0020-98' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '08.243.787/0001-24' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '1/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000049-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '1/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000049-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'PRESTAÇÃO DE SERVIÇOS DE APOIO ADMINISTRATIVO',
    'Posto de serviços: Assistente Operacional Nível I, de 44 (quarenta e quatro) horas.Posto 02',
    'Posto',
    '1',
    'R$6.037,08',
    'R$12.074,16',
    '5380',
    'Serviço',
    'Cabedelo (PB)'
FROM contrato_id
;