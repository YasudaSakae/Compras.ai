-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('SERVIÇO FLORESTAL BRASILEIRO', 'SFB', '37.115.375/0008-83')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('TELESUL COMUNICAÇÕES LTDA', '57.229.601/0001-98')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '5/2024',
        'Termo de Contrato Administrativo',
        '02209.001007/2023-32',
        NULL,
        'Contrato',
        '5/2024',
        's3://compras-ia-np/Contratos/00396895000125-000085-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '37.115.375/0008-83' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '57.229.601/0001-98' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '5/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000085-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '5/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000085-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Sala de Videoconferência',
    '',
    'Unidade',
    '4',
    'R$ 127.812,54',
    'R$ 511.250,16',
    '18627',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Serviço eventual/instalação',
    '',
    'Serviço',
    '1',
    'R$ 57.971,02',
    'R$ 57.971,02',
    '18627',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
;