-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('LABORATÓRIO FEDERAL DE DEFESA AGROPECUÁRIA DO MINISTÉRIO DA AGRICULTURA E PECUÁRIA', 'LFDA/MG', '00.396.895/0062-47')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('PONTUAL SERVICOS EMPRESARIAL LTDA.', '22.688.729/0001-35')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '16/2023',
        'Contrato',
        '21181.001208/2022-59',
        TO_DATE('03/07/2023', 'DD/MM/YYYY'),
        'Contrato',
        '16/2023',
        's3://compras-ia-np/Contratos/00396895000125-000149-2023.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0062-47' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '22.688.729/0001-35' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '16/2023'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000149-2023.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '16/2023'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000149-2023.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Recepcionista (7 postos)',
    'Serviços com dedicação exclusiva de mão de obra de Recepcionistas',
    'Mês',
    '12',
    'R$ 27.992,23',
    'R$ 335.906,75',
    '8729',
    'Serviço',
    'Pedro Leopoldo (MG)'
FROM contrato_id
;