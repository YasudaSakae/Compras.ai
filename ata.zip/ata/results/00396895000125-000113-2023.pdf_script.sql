-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('União, por meio do Laboratório Federal de Defesa Agropecuária/RS', 'LFDA/RS', '00.396.895/0045-46')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('Bruker do Brasil Comércio e Representação de Produtos Científicos Ltda', '04.755.378/0001-56')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '02/2023',
        'Contrato',
        '21043.001443/2022-13',
        TO_DATE('22/12/2017', 'DD/MM/YYYY'),
        'Contrato',
        '02/2023',
        's3://compras-ia-np/Contratos/00396895000125-000113-2023.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0045-46' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '04.755.378/0001-56' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '02/2023'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000113-2023.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '02/2023'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000113-2023.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Manutenção preventiva em sistema MALDI-TOF, modelo Autoﬂex Speed, número de série 826442000597, marca Bruker',
    'SERVP0013',
    'Serviço',
    '5',
    'R$ 15.384,00',
    'R$ 76.920,00',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Qualificação operacional em sistema MALDI-TOF, modelo Autoﬂex Speed, número de série 826442000597, marca Bruker',
    'DAL08706',
    'Serviço',
    '5',
    'R$ 25.000,00',
    'R$ 125.000,00',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Serviço de manutenção preventiva, corretiva e qualificação operacional (BRONZE) em sistema FT-NIR, modelo MPA, número de série 155000 - 1972, marca Bruker',
    '',
    'Serviço',
    '5',
    'R$ 29.052,00',
    'R$ 145.260,00',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Serviço de manutenção preventiva, corretiva e qualificação operacional (BRONZE) em sistema FT-NIR, modelo MPA, número de série 155000 - 1973, marca Bruker',
    '',
    'Serviço',
    '5',
    'R$ 29.052,00',
    'R$ 145.260,00',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Horas técnicas destinadas à manutenções corretivas. Será considerado o montante de 50 horas técnicas, sendo este quantitativo apenas estimado, pago sob demanda, e prevendo cenários atípicos de manutenção',
    '',
    'Horas',
    '250',
    'R$ 530,00',
    'R$ 132.500,00',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Custos de deslocamento para atendimento de manutenções corretivas. Será considerado o montante de 5 chamados anuais, sendo este quantitativo apenas estimado, pago sob demanda, e prevendo cenários atípicos de manutenção. Cabe ressaltar, que para os itens 3 e 4, pela características dos equipamentos, a proposta comercial já engloba dois atendimentos para manutenções corretivas/ano',
    '',
    'Deslocamento',
    '25',
    'R$ 6.904,00',
    'R$ 172.600,00',
    '16314',
    'Serviço',
    'Porto Alegre (RS)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Custos de cobertura de peças e consumíveis. Será considerado o montante de R$ 300.000,00, sendo este quantitativo apenas estimado, pago sob demanda, e prevendo cenários atípicos de manutenção',
    '',
    'Peças',
    '5',
    'R$ 300.000,00',
    'R$ 1.500.000,00',
    '453625',
    'Material',
    'Porto Alegre (RS)'
FROM contrato_id
;