-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('MINISTÉRIO DA AGRICULTURA E PECUÁRIA', 'MAPA', '00.396.895/0011-05')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('INGRAM MICRO BRASIL LTDA.', '01.771.935/0010-25')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '14/2024',
        'Contrato Administrativo',
        '21000.020025/2023-02',
        TO_DATE('09/05/2024', 'DD/MM/YYYY'),
        'Contrato',
        '14/2024',
        's3://compras-ia-np/Contratos/00396895000125-000148-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.396.895/0011-05' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '01.771.935/0010-25' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '14/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000148-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '14/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00396895000125-000148-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Firewall - Solução de plataforma de segurança denominada Next Generaon Firewall (NGFW) com instalação, suporte, garana e  licenciamento inclusos.',
    'Firewall - Solução de plataforma de segurança denominada Next Generaon Firewall (NGFW) com instalação, suporte, garana e  licenciamento inclusos.',
    'UNIDADE',
    '04',
    'R$ 1.062.500',
    'R$ 4.250.000,00',
    '484747',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Solução de armazenamento de logs e relatoria, com instalação, suporte, garana e  licenciamento inclusos.',
    'Solução de armazenamento de logs e relatoria, com instalação, suporte, garana e  licenciamento inclusos.',
    'UNIDADE',
    '01',
    'R$ 85.500,00',
    'R$ 85.500,00',
    '481647',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Solução para gerenciamento centralizado dos equipamentos, com instalação, suporte, garana e  licenciamento inclusos.',
    'Solução para gerenciamento centralizado dos equipamentos, com instalação, suporte, garana e  licenciamento inclusos.',
    'UNIDADE',
    '01',
    'R$ 102.900,00',
    'R$ 102.900,00',
    '481646',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Treinamento ministrado por proﬁssional cerﬁcado pelo fabricante.',
    'Treinamento ministrado por proﬁssional cerﬁcado pelo fabricante.',
    'CAPACITAÇÃO',
    '01',
    'R$ 18.500,00',
    'R$ 18.500,00',
    '16837',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Plataforma de ZTNA - Zero Trust Network Access,  com instalação, suporte, garana e licenciamento inclusos.',
    'Plataforma de ZTNA - Zero Trust Network Access,  com instalação, suporte, garana e licenciamento inclusos.',
    'SERVIÇO',
    '01',
    'R$ 737.000,00',
    'R$ 737.000,00',
    '27472',
    'Serviço',
    'Brasília (DF)'
FROM contrato_id
;