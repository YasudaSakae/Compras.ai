-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('Secretaria de Estado de Justiça e Cidadania do Distrito Federal', 'SEJUS', '08.685.528/0001-53')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('50.381.842 FRANCI ELLY HAD AD BARBOS A RAMOS', '50.381.842/0001-09')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '30/2023-SEJUS',
        'Contrato',
        '00400-00069180/2022-82',
        NULL,
        'Contrato',
        '30/2023-SEJUS',
        's3://compras-ia-np/Contratos/00394684000153-000028-2023.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '08.685.528/0001-53' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '50.381.842/0001-09' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '30/2023-SEJUS'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000028-2023.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '30/2023-SEJUS'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00394684000153-000028-2023.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'Autoclave',
    'Material: Aço Inox. Tipo: Horizontal, Modelo: Gravitacional, Operação: Automática, digital, característica Adicional: Sistemas de Secagem e segurança, Volume Câmara: 21L, composição: Sensores Temperatura e Pressão, Alarmes, outros componentes: 3 bandejas.',
    'UND',
    '3',
    'R$ 4.765,00',
    'R$ 14.295,00',
    '435568',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Maleta Para Transporte De Medicamento com 3 Bandejas',
    'Maleta medicamento, material estojo com 2 bandejas articuladas, dimensões altura 22 cm x largura 24 cm x comprimento 44 cm, componentes 2 mini estojos com 2 compartimentos cada um.',
    'UND',
    '8',
    'R$ 128,00',
    'R$ 1.024,00',
    '459268',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Esfigmomanômetro',
    'ajuste analógico, aneróide, tipo* de braço, faixa de operação até 300 mmhg, material braçadeira braçadeira em nylon, tipo fecho fecho em metal, tamanho infantil, adulto e adulto obeso.',
    'UND',
    '6',
    'R$ 98,00',
    'R$ 588,00',
    '432469',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Estetoscópio',
    'Estetoscópio haste: haste aço inox , tubo: tubo "y" pvc , auscultador: auscultador duplo aço inox , tipo: biauricular , acessórios: olivas anatômicas silicone.',
    'UND',
    '3',
    'R$ 83,00',
    'R$ 249,00',
    '438928',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Carro P/ Curativo Inox Com Balde E Bacia Em Inox',
    'Carro aço inox para curativo, tipo estrutura estrutura tubular e tampos em aço inox, tipo rodízio rodízios giratórios, acessórios gradil,suporte p/balde e bacia, medida 45 x 75 x 80 cm, outros componentes balde aço inox 5l, bacia aço inox.',
    'UND',
    '4',
    'R$ 820,00',
    'R$ 3.280,00',
    '380906',
    'Material',
    'Brasília (DF)'
FROM contrato_id
UNION ALL
SELECT

    id,
    'Caixa De Medicação Com Divisória',
    'Caixa organizadora transparente com 21 divisões de divisórias móveis. material: plástico durável, tamanho aproximado: 33 x 24 x 4,9cm.',
    'UND',
    '7',
    'R$ 25,00',
    'R$ 175,00',
    '290082',
    'Material',
    'Brasília (DF)'
FROM contrato_id
;